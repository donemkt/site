<?php
/**
 * Registers the subscribe form shortcode and adds it to the Visual Composer
 */

class Engage_Subscribe_Form {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_subscribe_form', array( $this, 'shortcode' ) );
		
	}	
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_subscribe_form', $atts ) );
		
		ob_start();	
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}		
		
		?>		
		
        <div class="widget-subscribe-form <?php echo esc_attr( $animation_class ); ?>" <?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
            <p><?php echo esc_html( $title ); ?></p>
            <h2><?php echo esc_html( $sub_title ); ?></h2>
            <form action="<?php echo esc_url( $mailchimp_form_action ); ?>">
                <input type="text" placeholder="<?php echo esc_attr( $placeholder_text ); ?>" name="email" id="email">
                <button class="btn solid" type="submit"><?php echo esc_html( $submit_text ); ?></button>
            </form>
            <div>
				<?php if ( $icon_type == 'fontawesome' ) { ?>
					<i class="<?php echo esc_attr( $icon_fontawesome ); ?>"></i>
				<?php } else {
					?>
					<i class="<?php echo esc_attr( $icon_ionicons ); ?>"></i>
					<?php }
				?>				
				<?php echo esc_html( $footer_text ); ?>
			</div>
        </div>    
        		
		<?php
		
		// Return outbut buffer
		return ob_get_clean();		
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Mailchimp Form", 'engage' ),
			"description"			=> esc_html__( "Mailchimp subscription form", 'engage' ),
			"base"					=> "engage_subscribe_form",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon" 					=> "engage-subscribe-form-icon",
			"params"				=> array(

				// General
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Mailchimp Form Action", 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "mailchimp_form_action",
					"value"			=> "http://domain.us1.list-manage.com/subscribe/post?u=numbers_go_here",
					"description"	=> esc_html__( "Enter the MailChimp form action URL.",'engage'),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Title', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "title",
					"value"			=> esc_html__('Enter subscribe form title','engage'),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Sub Title', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "sub_title",
					"value"			=> esc_html__('Enter subscribe form sub title','engage'),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Placeholder Text', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "placeholder_text",
					"value"			=> esc_html__('Enter your email','engage'),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Submit Button Text', 'engage' ),
					"param_name"	=> "submit_text",
					"value"			=> esc_html__( 'SUBSCRIBE', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Footer Text', 'engage' ),
					"param_name"	=> "footer_text",					
				),							
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Icon library', 'engage' ),
					'value'			=> array(						
										esc_html__( 'Ion Icons', 'engage' ) => 'ionicons',
										esc_html__( 'Font Awesome', 'engage' ) => 'fontawesome',						
										),
					'param_name'	=> 'icon_type',
					'description'	=> esc_html__( 'Select icon library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_fontawesome',
					'value'			=> 'fa fa-bicycle',
					'settings'		=> array(
										'emptyIcon' => false,
										// default true, display an "EMPTY" icon?
										'iconsPerPage' => 4000,
										// default 100, how many icons per/page to display
									   ),
					'dependency'	=> array(
										'element' => 'icon_type',
										'value' => 'fontawesome',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_ionicons',
					'value'			=> 'ion-cube',
					'settings'		=> array(
										'emptyIcon' => false, // default true, display an "EMPTY" icon?
										'type'		=> 'ionicons',
										'source'	=> engage_iconpicker_type_ionicons(),
										),
					'dependency'	=> array(
										'element'	=> 'icon_type',
										'value'		=> 'ionicons',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"         => array(
										esc_html__( 'None', 'engage' )      => '',                      
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',	                                          
									   ),
					"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__('Animation Delay Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__('Animation Duration Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Subscribe_Form();