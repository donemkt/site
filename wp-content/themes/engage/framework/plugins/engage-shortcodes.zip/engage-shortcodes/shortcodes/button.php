<?php
/**
 * Registers the button block shortcode and adds it to the Visual Composer
 */

class Engage_Button {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_button', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_button', $atts ) );
		
		ob_start();
		
		$button_target_scroll_class = '';		
		if( $button_target == 'scroll' ) {
			$button_target_scroll_class = 'btn-scroll';
		}		
		
		//button target attribute
		$button_target_attr = '';		
		if ( $button_target && $button_target != 'scroll' ) {
			$button_target_attr = 'target='.esc_attr( $button_target );
		}
		
		/*-----------------------------------------------------------------------------------*/
		/*	- Margin Style
		/*-----------------------------------------------------------------------------------*/
		$margin_style = '';
				
		if ( $margin_top ) {	
			$margin_style	.= 'margin-top:'. $margin_top .';';
		}

		if ( $margin_bottom ) {	
			$margin_style	.= 'margin-bottom:'. $margin_bottom .';';
		}
		
		//Background style
		if ( $margin_style ) {
			$margin_style = ' style="' . esc_attr( $margin_style ). '"';
		}
		
	
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		?>

		<div class="<?php echo esc_attr( $button_alignment ); ?>" >
			<a href="<?php echo esc_url( $button_url ); ?>" <?php echo $margin_style; ?> <?php echo $button_target_attr; ?> 
			         class="btn <?php echo esc_attr( $button_target_scroll_class ); ?> <?php echo esc_attr( $button_size ); ?> <?php echo esc_attr( $button_style ); ?> <?php echo esc_attr( $animation_class ); ?>" 
						 <?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>> 
				
				<?php if ( $place_icon == 'left' && $icon_type == 'fontawesome'  ) { ?>
					<i class="btn-icon-left <?php echo esc_attr( $icon_fontawesome ); ; ?>"></i>
				<?php } else if ( $place_icon == 'left' ) {
				?>
					<i class="btn-icon-left <?php echo esc_attr( $icon_ionicons ); ?>"></i>
				<?php }
				?>	
				<?php echo esc_html( $button_text ); ?>
					<?php if ( $place_icon == 'right' && $icon_type == 'fontawesome' ) { ?>
					<i class="btn-icon-right <?php echo esc_attr( $icon_fontawesome ); ?>"></i>
				<?php } else if ( $place_icon == 'right' ) {
				?>
					<i class="btn-icon-right <?php echo esc_attr( $icon_ionicons ); ?>"></i>
				<?php }
				?>	
			</a>
		</div>
		<?php
		
		// Return outbut buffer
		return ob_get_clean();	
		
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Button", 'engage' ),
			"description"			=> esc_html__( "Add Button", 'engage' ),
			"base"					=> "engage_button",
			"icon" 					=> "engage-button-icon",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),			
			"params"				=> array(
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Button Style", 'engage' ),
					"param_name"	=> "button_style",
					"value"			=> array(						
						esc_html__( "Solid", 'engage')		=> "solid",
						esc_html__( "Black Bordered / Theme Color on hover", 'engage' )	=> "bordered-black slide-effect-theme",
						esc_html__( "White Bordered / Theme Color on hover", 'engage' )	=> "bordered-white slide-effect-theme",
						esc_html__( "Black Bordered / Button Color on hover", 'engage' )	=> "bordered-black slide-effect",
						esc_html__( "White Bordered / Button Color on hover", 'engage' )	=> "bordered-white slide-effect",
						esc_html__( "Black Bordered / Opacity effect on hover", 'engage' )	=> "bordered-black opacity-effect",
						esc_html__( "White Bordered / Opacity effect on hover", 'engage' )	=> "bordered-white opacity-effect",
					),					
				),
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Button: Alignment", 'engage' ),
					"param_name"	=> "button_alignment",
					"value"			=> array(
						esc_html__( "Left", 'engage')		=> "align-left",
						esc_html__( "Right", 'engage')		=> "align-right",
						esc_html__( "Center", 'engage' )	=> "align-center",
					),					
				),
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Button: Size", 'engage' ),
					"param_name"	=> "button_size",
					"value"			=> array(
						esc_html__( "Normal", 'engage')		=> "normal",
						esc_html__( "Large", 'engage')		=> "big",						
					),					
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Button: Text", 'engage' ),
					"param_name"	=> "button_text",
					"value"			=> "SUBSCRIBE US",					
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Button: URL", 'engage' ),
					"param_name"	=> "button_url",
					"value"			=> "#",					
				),				
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Button: Link Target", 'engage' ),
					"param_name"	=> "button_target",
					"value"			=> array(
						esc_html__( "None", 'engage')				=> "",
						esc_html__( "Scroll to Section", 'engage')	=> "scroll",
						esc_html__( "Self", 'engage')				=> "_self",
						esc_html__( "New Page", 'engage' )			=> "_blank",
					),					
				),
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Place Icon", 'engage' ),
					"param_name"	=> "place_icon",
					"value"			=> array(
						esc_html__( "None", 'engage')		=> "",
						esc_html__( "Left", 'engage')		=> "left",
						esc_html__( "Right", 'engage' )		=> "right",
					),
					"group"			=> esc_html__( 'Icon', 'engage' ),
				),						
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Icon library', 'engage' ),
					'value'			=> array(						
										esc_html__( 'Ion Icons', 'engage' ) => 'ionicons',
										esc_html__( 'Font Awesome', 'engage' ) => 'fontawesome',						
										),
					'param_name'	=> 'icon_type',
					'description'	=> esc_html__( 'Select icon library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_fontawesome',
					'value'			=> 'fa fa-bicycle',
					'settings'		=> array(
										'emptyIcon' => false,
										// default true, display an "EMPTY" icon?
										'iconsPerPage' => 4000,
										// default 100, how many icons per/page to display
									   ),
					'dependency'	=> array(
										'element' => 'icon_type',
										'value' => 'fontawesome',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_ionicons',
					'value'			=> 'ion-cube',
					'settings'		=> array(
										'emptyIcon' => false, // default true, display an "EMPTY" icon?
										'type'		=> 'ionicons',
										'source'	=> engage_iconpicker_type_ionicons(),
										),
					'dependency'	=> array(
										'element'	=> 'icon_type',
										'value'		=> 'ionicons',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Margin Top', 'engage' ),
					'param_name'	=> 'margin_top',
					'group'			=> esc_html__( 'Margin', 'engage' ),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Margin Bottom', 'engage' ),
					'param_name'	=> 'margin_bottom',
					'group'			=> esc_html__( 'Margin', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"         => array(
										esc_html__( 'None', 'engage' ) => '',
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',						                    
									),
					"description"	=> esc_html__( 'Animation Effect for Address block.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Button();