<?php
/**
 * Registers the pricing shortcode and adds it to the Visual Composer 
 */

class Engage_Pricing_Box {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_pricing_box', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_pricing_box', $atts ) );
		
		ob_start();
		
		//font style
		$font_style = '';
		if ( $font_color ) {	
			$font_style = 'color:'. $font_color .';';
		}

		if ( $font_style ) {
			$font_style = ' style="' . esc_attr( $font_style ) . '"';
		}
		
		//theme border class
		$theme_border_class = '';
		
		if ( $pricing_style == 'basic' ) {
			$theme_border_class = 'theme-border-color';
		}
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if ( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		?>
		
		<div class="pricing-box <?php echo esc_attr( $pricing_style ); ?> <?php echo esc_attr( $animation_class ); ?>" 
					<?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>> 
			
			<?php if ( $pricing_style == 'modern' && $popular ) { ?>
				<span class="pricing-popular theme-color"><?php echo esc_html( $popular_text ); ?></span>
			<?php } ?>		
			
			<div class="pricing-price-wrap <?php echo esc_attr( $theme_border_class ); ?>" <?php echo $font_style; ?> >
				
				<?php if ( $pricing_style == 'basic' ) { ?>
				<div class="pricing-title"><?php echo esc_html( $pricing_title ); ?></div>
				<?php } ?>
				
				<div class="pricing-price">
					<span class="pricing-unit"><?php echo esc_html( $currency ); ?></span>
					<?php echo esc_html( $value ); ?>
				</div>
				<small class="pricing-tenure"><?php echo esc_html( $tenure ); ?></small> 
			</div>

			<?php if ( $pricing_style == 'modern' ) { ?>	
				<div class="pricing-sep"></div>
			<?php } ?>		
				
			<?php if ( $pricing_style == 'basic' && $popular ) { ?>
				<div class="pricing-popular theme-bg-color"><?php echo esc_html( $popular_text ); ?></div>
			<?php } ?>
			
			<?php echo wpb_js_remove_wpautop( $content ); ?>
		
			<div class="pricing-action"> 
				<a class="btn <?php echo esc_attr( $button_style ); ?>" href="<?php echo esc_url( $button_url ); ?>"><?php echo esc_html( $button_text ); ?></a>
			</div>
		</div>

		<?php
		
		// Return output buffer
		return ob_get_clean();								
	}
	
	function shortcode_vcmap() {

		vc_map( array(
			"name"					=> esc_html__( "Pricing Box", 'engage' ),
			"description"			=> esc_html__( "Insert a pricing column", 'engage' ),
			"base"					=> "engage_pricing_box",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"					=> "engage-pricing-box-icon",			
			"params"				=> array(	
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( 'Pricing Style', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "pricing_style",
					"value"         => array(
											esc_html__( "Modern", 'engage' )	 => "modern",
											esc_html__( "Basic", 'engage' )	 => "basic",											
									    ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Pricing Title", 'engage'),
					"param_name"	=> "pricing_title",					
					"value"			=> "Basic",
					"dependency"	=> array(
										 'element'	=> 'pricing_style',
										 'value'	=> 'basic',
										),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Pricing value", 'engage'),
					"param_name"	=> "value",
					"admin_label"	=> true,
					"value"			=> "19"
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Currency Symbol", 'engage'),
					"param_name"	=> "currency",
					"admin_label"	=> true,
					"value"			=> "$"
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Pricing Tenure text", 'engage'),
					"description"	=> esc_html__('Smaller text e.g. some additional info or period: daily, monthly etc.', 'engage'),
					"param_name"	=> "tenure",
					"value"			=> "per month"
				),
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Pricing Text Color', 'engage' ),
					"description"	=> esc_html__('Choose Color for Value, Currency and Tenure text.', 'engage'),
					"param_name"	=> "font_color",				
				),			
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Popular", 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "popular",
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes'
										)
				),	
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Popular text", 'engage'),
					"param_name"	=> "popular_text",					
					"value"			=> "POPULAR",
					"dependency"	=> array(
										 'element'	 => 'popular',
										 'not_empty' => true,
										),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Custom button url", 'engage'),
					"description"	=> esc_html__('For example: http://www.themeforest.net', 'engage'),
					"param_name"	=> "button_url",
					"value"			=> "http://www.themeforest.net"
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Button text", 'engage'),
					"param_name"	=> "button_text",
					"value"			=> "Purchase"
				),	
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( 'Button Style', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "button_style",
					"value"         => array(
											esc_html__( "Solid", 'engage')		=> "solid",
											esc_html__( "Black Bordered / Theme Color on hover", 'engage' )	=> "bordered-black slide-effect-theme",
											esc_html__( "White Bordered / Theme Color on hover", 'engage' )	=> "bordered-white slide-effect-theme",
											esc_html__( "Black Bordered / Button Color on hover", 'engage' )	=> "bordered-black slide-effect",
											esc_html__( "White Bordered / Button Color on hover", 'engage' )	=> "bordered-white slide-effect",
											esc_html__( "Black Bordered / Opacity effect on hover", 'engage' )	=> "bordered-black opacity-effect",
											esc_html__( "White Bordered / Opacity effect on hover", 'engage' )	=> "bordered-white opacity-effect",
									    ),
				),
				array(
					"type"			=> "textarea_html",
					"heading"		=> esc_html__( 'Features', 'engage' ),
					"param_name"	=> "content",
					"value"			=> '<ul class="pricing-features">
											<li>30GB Storage</li>
											<li>512MB Ram</li>
											<li>10 databases</li>
											<li>1,000 Emails</li>
											<li>25GB Bandwidth</li>
										</ul>',
					"description"	=> esc_html__('Enter your pricing content. You can use a UL list as shown by default but anything would really work!','engage'),
					"group"			=> esc_html__( 'Features', 'engage' ),
				),					
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"         => array(
										esc_html__( 'None', 'engage' )      => '',                      
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',	                    
									  ),
					"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__('Animation Delay Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__('Animation Duration Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );

	}
}

new Engage_Pricing_Box();
