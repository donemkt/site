<?php
/**
 * Registers the Special Heading shortcode and adds it to the Visual Composer
 */

class Engage_Special_Heading {
	
	function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_special_heading', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_special_heading', $atts ) );	
		
		ob_start();	
		
		
		$light_heading_class = '';
		if ( $light_heading ) {
			
			$light_heading_class = 'light';
		}
		
		$theme_color_class = '';		
		if ( $use_theme_color ) {			
			$theme_color_class = 'theme-color';
			
			if ( $upper_title_style == 'bordered' ) {
				$theme_color_class .= ' theme-border-color';
			}
		}
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}		
		
		?>
		
		<div class="special-heading clearfix align-<?php echo esc_attr( $align_heading ); ?> <?php echo esc_attr( $light_heading_class ); ?> <?php echo esc_attr( $animation_class ); ?>" 
					<?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>

			<?php if ( $use_upper_title ) { ?>			
				<span class="upper-title <?php echo esc_attr( $upper_title_style ); ?> <?php echo esc_attr( $theme_color_class ); ?>"><?php echo esc_html( $upper_title ); ?></span>
			<?php } ?>

			<?php if ( $title_style == 'bordered' ) { ?>
				<div class="bordered-title">	
				<?php } ?>
					
				<?php if ( $title && $title_style == 'titlebg' ) { ?>	
					<div class="title-bg theme-bg-color"><h2><?php echo wp_kses( $title, array( 'br' => array() ) ); ?></h2></div>
				<?php } 
				elseif ( $title ) { ?>
					<h2 class="title"><?php echo wp_kses( $title, array( 'br' => array() ) ); ?></h2>					
				<?php }?>

				<?php if ( $title_style == 'bordered' ) { ?>	
					<span class="bordered-title-sep"></span> 
				</div>
			<?php } ?>			

			<?php if ( $separator_style ) { ?>
				<span class="<?php echo esc_attr( $separator_style ); ?>"></span> 			
			<?php } ?>

		</div>

		<?php
		
		// Return outbut buffer
		return ob_get_clean();		
		
	}
	
	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Special Heading", 'engage' ),
			"description"			=> esc_html__( "Special Heading", 'engage' ),
			"base"					=> "engage_special_heading",
			"icon" 					=> "engage-special-heading-icon",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"params"				=> array(				
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Heading Alignment", 'engage' ),
					"param_name"	=> "align_heading",
					"value"         => array(
										esc_html__( 'Left', 'engage' )      => 'left',									
										esc_html__( 'Center', 'engage' )    => 'center'                        
										),					
					"description"	=> esc_html__( 'You can choose the heading alignment.', 'engage' ),
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Upper Heading", 'engage' ),
					"param_name"	=> 'use_upper_title',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"description"	=> esc_html__("Check if you want upper heading.", 'engage')
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Upper Heading", 'engage' ),
					"admin_label"	=> true,				
					"param_name"	=> "upper_title",
					"dependency"	=> array(
										'element'	=> 'use_upper_title',
										'not_empty'	=> true,
										),
					"description"	=> esc_html__('Enter the text for upper heading.','engage'),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Upper Heading Style", 'engage' ),
					"param_name"	=> "upper_title_style",
					"value"         => array(
										esc_html__( 'Normal', 'engage' )      => 'normal',
										esc_html__( 'Bordered', 'engage' )    => 'bordered',										
										esc_html__( 'Has Line', 'engage' )    => 'line',										
										),		
					"dependency"	=> array(
										'element'	=> 'use_upper_title',
										'not_empty'	=> true,
										),
					"description"	=> esc_html__( 'Choose the style for upper heading.', 'engage' ),
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Upper Heading", 'engage' ),
					"param_name"	=> 'use_theme_color',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"dependency"	=> array(
										'element'	=> 'use_upper_title',
										'not_empty'	=> true,
										),
					"description"	=> esc_html__("Choose Color for upper heading.", 'engage'),
				),				
				array(
					"type"			=> "textarea",
					"heading"		=> esc_html__( "Heading", 'engage' ),
					"admin_label"	=> true,				
					"param_name"	=> "title",					
					"description"	=> esc_html__('Enter the text for Heading.','engage'),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Heading Style", 'engage' ),
					"param_name"	=> "title_style",
					"value"         => array(
										esc_html__( 'Normal', 'engage' )      => 'normal',
										esc_html__( 'Bordered', 'engage' )     => 'bordered',										
										esc_html__( 'With Background Color', 'engage' )     => 'titlebg',										
										),					
					"description"	=> esc_html__( 'Choose heading style.', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Heading Separator", 'engage' ),
					"param_name"	=> "separator_style",
					"value"         => array(
										esc_html__( 'None', 'engage' )		    => '',
										esc_html__( 'Single Dash', 'engage' )   => 'single-dash',										
										esc_html__( 'Double Dash', 'engage' )   => 'double-dash',										
										esc_html__( 'Triple Dash', 'engage' )   => 'triple-dash',										
										),
					"dependency"	=> array(
										'element'	=> 'title_style',
										'value'	    => array ( 'normal' ),
										),
					"description"	=> esc_html__( 'Choose the separator style for heading.', 'engage' ),
				),			
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( 'Use Light Heading', 'engage' ),
					"param_name"	=> "light_heading",
					"value"			=> array(
										esc_html__( 'Yes', 'engage' )	=> 'yes',
										),				
					"description"	=> esc_html__( "Check for white color heading and upper heading.", 'engage' ),										
				),												
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"         => array(
											esc_html__( 'None', 'engage' )      => '',                      
											esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
											esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
											esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
											esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
											esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
											esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
											esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
											esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
											esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
											esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
											esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
											esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
											esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
											esc_html__( 'flipInX', 'engage' ) => 'flipInX',
											esc_html__( 'flipInY', 'engage' ) => 'flipInY',
											esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
											esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
											esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
											esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
											esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
											esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
											esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
											esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
											esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
											esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
											esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
											esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
											esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
											esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
											esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
											esc_html__( 'rollIn', 'engage' ) => 'rollIn',	                          
										),
					"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__('Animation Delay Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__('Animation Duration Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Special_Heading();
