<?php
/**
 * Registers the client logo slider shortcode and adds it to the Visual Composer
 */

class Engage_Client_Logo_Slider {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_client_logo', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {	
		
		extract( vc_map_get_attributes( 'engage_client_logo', $atts ) );
			
		ob_start();		
		
		// Get Attachments		
		if ( $image_ids ) {
			$attachments = explode( ",", $image_ids );
			$attachments = array_combine( $attachments, $attachments );
		}
		else {	
			
			for ( $index = 0; $index <= 6; $index++  ) {
				$attachments[ $index ] = ENGAGE_IMAGE_URL . '/logo/client-logo.png';
			}			
		} 		
		
		
		$data_attr  = '';			
	
		$data_attr .= ( $auto_play )			  ? ' data-autoplay = true '								: '';			
		$data_attr .= ( $auto_play &&
						$slideshow_speed )		  ? ' data-autoplayspeed = '.intval( $slideshow_speed )		: '';
		$data_attr .= ( $auto_play &&
						$hover_pause )			  ? ' data-stoponhover = true '								: '';
		$data_attr .= ( $auto_play &&
						$infinite_loop )		  ? ' data-loop = true '									: '';	
		$data_attr .= ( $desktop_items )	  	  ? ' data-items = '.intval( $desktop_items )				: '5';
		$data_attr .= ( $tablet_items )			  ? ' data-items-tablet = '.intval( $tablet_items )			: '3';
		$data_attr .= ( $mobile_landscape_items ) ? ' data-items-mobile-landscape = '.intval( $mobile_landscape_items ) : '1';
		$data_attr .= ( $mobile_portrait_items )  ? ' data-items-mobile-portrait = '.intval( $mobile_portrait_items )	: '1';
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if ( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay = "'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration = "'.esc_attr( $animation_duration ).'s"';
		}
			
		?>

		<div class="golo-carousel client-slider <?php echo esc_attr( $animation_class ); ?>" <?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?> <?php echo $data_attr; ?>>
		<?php
		foreach ( $attachments as $attachment ) {
			
			if ( $image_ids ) {
				$attachment_img	= wp_get_attachment_url( $attachment );
			}
			else {
				$attachment_img	= $attachment;
			}
			
			?>
			
			<div class="item"><img src="<?php echo esc_url( $attachment_img ); ?>" class="img-responsive" alt="media"></div>
			
			<?php
		}
		
		?>
		</div>
			
		<?php
		
		// Return outbut buffer
		return ob_get_clean();	
	}
	
	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Client Logo", 'engage' ),
			"description"			=> esc_html__( "Client logo slider.", 'engage' ),
			"base"					=> "engage_client_logo",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"					=> "engage-client-logo-icon",
			"params"				=> array(				
				array(
					"type"			=> "attach_images",
					"admin_label"	=> true,				
					"heading"		=> esc_html__( "Attach Images", 'engage' ),
					"param_name"	=> "image_ids",
					"description"	=> esc_html__( "Select your images.", 'engage' ),					
				),							
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Auto Play", 'engage' ),
					"param_name"	=> "auto_play",					
					"value"			=> array(
										 esc_html__( 'Yes', 'engage' ) => 'yes',						
									   ),				
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Slideshow speed", 'engage' ),
					"param_name"	=> "slideshow_speed",
					"description"	=> esc_html__( 'Choose slideshow speed (in milliseconds). Default is 1000.', 'engage' ),
					"value"			=> "1000",
					"dependency"	=> array(
										'element'	=> 'auto_play',
										'not_empty' => true,
										),
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Infinite Loop", 'engage' ),
					"param_name"	=> "infinite_loop",
					"value"			=> array(
										esc_html__( 'Yes', 'engage' ) => 'yes',						
										),
					"dependency"	=> array(
										"element"	=> 'auto_play',
										"not_empty"	=> true,
										),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Pause slideshow", 'engage' ),
					"description"	=> esc_html__( "Pause slideshow when you hover over slide image", 'engage' ),
					"param_name"	=> "hover_pause",
					"value"			=> array(
										 esc_html__( 'Yes', 'engage' ) => 'yes',					
										),
					"dependency"	=> array(
										'element'	=> 'auto_play',
										'not_empty' => true,
										),
				),
				// Responsive Settings
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Desktop : Items To Display', 'engage' ),
					"param_name"	=> "desktop_items",
					"value"			=> "5",					
					"group"			=> esc_html__( 'Responsive Slider', 'engage' ),					
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Tablet (768px-659px): Items To Display', 'engage' ),
					"param_name"	=> "tablet_items",
					"value"			=> "3",					
					"group"			=> esc_html__( 'Responsive Slider', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Mobile Landscape (480px-767px): Items To Display', 'engage' ),
					"param_name"	=> "mobile_landscape_items",
					"value"			=> "1",					
					"group"			=> esc_html__( 'Responsive Slider', 'engage' ),
				),
				array(
					"type"			=> 'textfield',
					"heading"		=> esc_html__( 'Mobile Portrait (0-479px): Items To Display', 'engage' ),
					"param_name"	=> 'mobile_portrait_items',
					"value"			=> '1',					
					"group"			=> esc_html__( 'Responsive Slider', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					'value'         => array(
										esc_html__( 'None', 'engage' ) => '',
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',						                  
									),
					"description"	=> esc_html__( 'Animation Effect for client.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Client_Logo_Slider();