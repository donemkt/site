<?php
/**
 * Registers the twitter feeds slider shortcode and adds it to the Visual Composer 
 */

class Engage_Twitter_Feeds_Slider {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_twitter_feeds_slider', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_twitter_feeds_slider', $atts ) );
		
		ob_start();
		
		$data_attr  = '';
		$data_attr .= ( $navigation )        ? ' data-nav = true '								   : '';		
		$data_attr .= ( $navigation && 
						$navigation_speed )  ? ' data-navspeed = '.intval( $navigation_speed )	   : '';				
		$data_attr .= ( $pagination )		 ? ' data-dots = true '								   : '';		
		$data_attr .= ( $pagination &&
						$pagination_speed )  ? ' data-dotsspeed = '.intval( $pagination_speed )	   : '';		
		$data_attr .= ( $auto_play )		 ? ' data-autoplay = true '							   : '';			
		$data_attr .= ( $auto_play &&
						$slideshow_speed )   ? ' data-autoplayspeed = '.intval( $slideshow_speed ) : '';
		$data_attr .= ( $auto_play &&
						$hover_pause )		 ? ' data-stoponhover = true '						   : '';
		$data_attr .= ( $auto_play &&
						$infinite_loop )	 ? ' data-loop = true '								   : '';		
		
		$dark_text_class = '';
		if ( $dark_text ) {	
			$dark_text_class = 'dark';
		}
		
		//Twitter Icon Color
		$icon_style = '';
		$icon_theme_color_class = '';
		$icon_wrap_theme_color_class = '';
		
		if ( $icon_use_theme_color ) {
			$icon_theme_color_class = 'theme-color';		
			$icon_wrap_theme_color_class = 'class = theme-color';			
		}
		elseif ( $icon_color ) {	
			$icon_style = 'color:'. $icon_color .';';
		}	

		if ( $icon_style ) {
			$icon_style = ' style="' . esc_attr( $icon_style ) . '"';
		}
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if ( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
	
		$twitter_options = array();
		global $engage_theme_settings;
		
		/** Set access tokens here - see: https://dev.twitter.com/apps/ **/
		$settings = array(
			'oauth_access_token'		=>	$engage_theme_settings['access-token'],
			'oauth_access_token_secret' =>	$engage_theme_settings['access-token-secret'],
			'consumer_key'				=>	$engage_theme_settings['consumer-key'],
			'consumer_secret'			=>	$engage_theme_settings['consumer-secret-key']
		);
		
		//$twitter_id = 'envato';
		
		/* config */
		$url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
		$getfield = '?count='.$tweets_count.'&screen_name='.$twitter_id.'&exclude_replies=true';
		$requestMethod = 'GET';
		
		try {
				
			$twitter = new Twitter_API_WordPress( $settings );
			$tweets = $twitter -> set_get_field( $getfield ) -> build_oauth( $url, $requestMethod) -> process_request();
			$tweets = json_decode( $tweets );

			if ( $tweets && is_array( $tweets ) ) {		

				$carousel_class = 'golo-carousel';

				if ( count( $tweets ) == 1 ) {
					$carousel_class = 'no-carousel';
				}	
			?>

				<div class="tweets <?php echo esc_attr( $dark_text_class ); ?> <?php echo esc_attr( $animation_class ); ?>" <?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
					<span <?php echo esc_attr( $icon_wrap_theme_color_class ); ?> <?php echo $icon_style; ?>>
						<i class="fa fa-twitter <?php echo esc_attr( $icon_theme_color_class ); ?>" <?php echo $icon_style; ?>></i>
					</span>
					<u>@<?php echo esc_html( $twitter_id ); ?></u>
					<div class="<?php echo esc_attr( $carousel_class ); ?>" <?php echo $data_attr; ?>> 	

					<?php foreach ( $tweets as $tweet ) { 

						$tweetdate = new DateTime( $tweet -> created_at );
						$tweetdate = strtotime( $tweetdate -> format( 'Y-m-d H:i:s' ) );
						$currentdate = strtotime( date( 'Y-m-d H:i:s' ) );  
						$days = $this -> twitter_time_ago( $tweetdate, $currentdate );

					?>
						<div>						
							<p><?php echo esc_html( $tweet->text ); ?></p>						
							<u><?php echo esc_html( $days ); ?></u>
						</div>

					<?php } ?>

					</div>
				</div>
			<?php
			}			
			else
			{ ?>
				<div class="tweets <?php echo esc_attr( $dark_text_class ); ?>">
				<span <?php echo esc_attr( $icon_wrap_theme_color_class ); ?> <?php echo $icon_style; ?>>
					<i class="fa fa-twitter <?php echo esc_attr( $icon_theme_color_class ); ?>" <?php echo $icon_style; ?>></i>
				</span>
				<div><p class="err-msg"><?php esc_html_e( 'Please set your Twitter account and your Twitter API Key in Theme Options! Thank You For Purchasing Engage!', 'engage' ); ?> </p></div>
				</div>
			<?php
			}

		} catch ( Exception $e ) { ?>
			<div class="tweets <?php echo esc_attr( $dark_text_class ); ?>">
			<span <?php echo esc_attr( $icon_wrap_theme_color_class ); ?> <?php echo $icon_style; ?>>
				<i class="fa fa-twitter <?php echo esc_attr( $icon_theme_color_class ); ?>" <?php echo $icon_style; ?>></i>
			</span>
			<div><p class="err-msg"><?php esc_html_e( 'Please set your Twitter account and your Twitter API Key in Theme Options! Thank You For Purchasing Engage!', 'engage' ); ?> </p></div>
			</div>
		<?php
		}
        
       // Return outbut buffer
		return ob_get_clean();		
		
		
	}
	
	function twitter_time_ago( $oldTime, $newTime ) {
		 
		$timeCalc = $newTime - $oldTime;
		
		if ( $timeCalc > ( 60*60*24 ) ) { $timeCalc = round( $timeCalc/60/60/24 ) . esc_html__( " days ago" , 'engage' ); }
		else if ( $timeCalc > ( 60*60 ) ) { $timeCalc = round( $timeCalc/60/60 ) . esc_html__( " hours ago" , 'engage' ); }
		else if ( $timeCalc > 60 ) { $timeCalc = round( $timeCalc/60 ) . esc_html__( " minutes ago" , 'engage' ); }
		else if ( $timeCalc > 0 ) { $timeCalc .= esc_html__( " seconds ago", 'engage' ); }
		
		return $timeCalc;
	}

	function shortcode_vcmap() {

		vc_map( array(
			"name"					=> esc_html__( "Twitter Feeds Slider", 'engage' ),
			"description"			=> esc_html__( "Recent twitter_feeds slider", 'engage' ),
			"base"					=> "engage_twitter_feeds_slider",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"					=> "engage-twitter-feeds-slider-icon",		
			"params"				=> array(
				
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Twitter Id", 'engage' ),
					"param_name"	=> "twitter_id",
					"description"	=> esc_html__( 'Enter the twitter id to fetch the tweets.', 'engage' ),
					"value"			=> ""
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Tweets Count", 'engage' ),
					"param_name"	=> "tweets_count",
					"description"	=> esc_html__( 'Number of tweets to fetch.', 'engage' ),
					"value"			=> "5"
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Twitter Icon", 'engage' ),
					"param_name"	=> 'icon_use_theme_color',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),					
					"description"	=> esc_html__("Check it to Apply theme color to twitter icon.", 'engage'),					
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Twitter Icon', 'engage' ),
					"param_name"	=> "icon_color",		
					"dependency"	=> array(
										'element'	=> 'icon_use_theme_color',
										'is_empty'	=> true,
										),
					"value"			=> "#ffffff",
					"description"	=> esc_html__("Choose Color for twitter icon.", 'engage'),				
				),			
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( 'Use Dark Text', 'engage' ),
					"param_name"	=> "dark_text",
					"value"			=> array(
										esc_html__( 'Yes', 'engage' )	=> 'yes',
										),
					"description"	=> esc_html__( "Check for black color tweet text.", 'engage' ),										
				),								
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Show Pagination", 'engage' ),
					"description"	=> esc_html__( "Choose to show slider pagination", 'engage' ),
					"param_name"	=> "pagination",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes'
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Pagination speed", 'engage' ),
					"param_name"	=> "pagination_speed",
					"description"	=> esc_html__( 'Choose pagination speed (in milliseconds)', 'engage' ),
					"value"			=> "1000",
					"dependency"	=> array(
											'element' => 'pagination',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Show Navigation", 'engage' ),
					"description"	=> esc_html__( "Choose to show slider navigation", 'engage' ),
					"param_name"	=> "navigation",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes'
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Navigation speed", 'engage' ),
					"param_name"	=> "navigation_speed",
					"description"	=> esc_html__( 'Choose navigation speed (in milliseconds)', 'engage' ),
					"value"			=> "1000",
					"dependency"	=> array(
											'element' => 'navigation',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Auto Play", 'engage' ),
					"param_name"	=> "auto_play",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes'
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Slideshow speed", 'engage' ),
					"param_name"	=> "slideshow_speed",
					"description"	=> esc_html__( 'Choose slideshow speed (in milliseconds)', 'mthemes' ),
					"value"			=> "1000",
					"dependency"	=> array(
											'element' => 'auto_play',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Infinite Loop", 'engage' ),
					"param_name"	=> "infinite_loop",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes',
										),
					"dependency"	=> array(
											'element'	=> 'auto_play',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Pause slideshow", 'engage' ),
					"description"	=> esc_html__( "Pause slideshow when you hover over slide image", 'engage' ),
					"param_name"	=> "hover_pause",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes',
										),
					"dependency"	=> array(
											'element' => 'auto_play',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),		
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"			=> array(
											esc_html__( 'None', 'engage' ) => '',
											esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
											esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
											esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
											esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
											esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
											esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
											esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
											esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
											esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
											esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
											esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
											esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
											esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
											esc_html__( 'flipInX', 'engage' ) => 'flipInX',
											esc_html__( 'flipInY', 'engage' ) => 'flipInY',
											esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
											esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
											esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
											esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
											esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
											esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
											esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
											esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
											esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
											esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
											esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
											esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
											esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
											esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
											esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
											esc_html__( 'rollIn', 'engage' ) => 'rollIn',
										),
					"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",
					"description"	=> esc_html__( 'Animation Delay Timming.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",
					"description"	=> esc_html__( 'Animation Duration Timming.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
			),			
		) );
	}
}

new Engage_Twitter_Feeds_Slider();