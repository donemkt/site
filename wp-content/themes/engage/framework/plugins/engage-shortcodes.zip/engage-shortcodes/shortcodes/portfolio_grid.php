<?php
/**
 * Registers the portfolio grid shortcode and adds it to the Visual Composer
 */

class Engage_Portfolio_Grid {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_portfolio_grid', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_portfolio_grid', $atts ) );
		
		ob_start();				
	
		$data_attr  = '';
		$data_attr .= ( $grid_columns )      ? ' data-medium-desktop = '.intval( $grid_columns )    : '';		
		$data_attr .= ( $grid_columns )      ? ' data-tablet = '.intval( $grid_columns )		    : '';		
		$data_attr .= ( $caption )			 ? ' data-caption = '.esc_attr( $caption )			    : '';		
		$data_attr .= ( $filter_animation )	 ? ' data-animation = '.esc_attr( $filter_animation )	: '';	
		$data_attr .= ( $horizontal_space )	 ? ' data-gaphorizontal = '.intval( $horizontal_space ) : '';
		$data_attr .= ( $vertical_space )	 ? ' data-gapvertical = '.intval( $vertical_space )		: '';
		$data_attr .= ( $text_align )		 ? ' data-textalign = '.esc_attr( $text_align )			: '';	
		
		
		$use_theme_color_class = '';		
		if ( $use_theme_color ) {			
			$use_theme_color_class = 'theme-color';
		}	
		
		?>

		
		<?php if ( $filter ) { ?>

			<div id="filters-container" class="cbp-l-filters-<?php echo esc_attr( $filter_align ); ?> <?php echo esc_attr( $filter_style ); ?> ">
				<div data-filter="*" class="cbp-filter-item-active  cbp-filter-item"> <?php echo esc_html_e( 'All', 'engage' ); ?>

					<?php if ( $filter_counter ) { ?>
						<div class="cbp-filter-counter"></div>			
					<?php } ?>

				</div>
				<?php
				$args = array(
					'hierarchical' => false,
					'parent' => 0,
					'taxonomy' => 'portfolio_category'
				);

				$categories = get_categories( $args );

				if ( !empty( $categories ) ) {
					foreach ( $categories as $key => $value ) {
						?>
						<div data-filter=.<?php echo esc_attr( $value->slug ); ?> class="cbp-filter-item"> <?php echo esc_html( $value->name ); ?>				
							<?php if ( $filter_counter ) { ?>
								<div class="cbp-filter-counter"></div>
								<?php
							}
							?>                
						</div>
							<?php
						}
					}
					?>

			</div><!--End #filters-container-->
		<?php } ?>

		<?php
		
		$args = array(
			'post_type'		 => 'portfolio',
			'posts_per_page' => $posts_per_page,
			'order'			 => $order,
			//'orderby'		 => $orderby,
			'orderby'		 => 'menu_order',
			'post_status'	 => 'publish'
		);
				
		$portfolio_query = new WP_Query( $args );
		
		if( $portfolio_query -> have_posts() ) {	
		
		?>
		
		<div id="portfolio-grid-container" <?php echo $data_attr; ?>>
			
		<?php
		
		foreach ( $portfolio_query -> posts as $post ) {
			
			setup_postdata( $post );		
			
			// Post Vars				
			$post_id			= $post -> ID;
			$terms				= wp_get_post_terms( $post_id, 'portfolio_category' );						
			$portfolio_type		= get_post_meta( $post_id, 'portfolio_type', true );
			$portfolio_open_in	= get_post_meta( $post_id, ENGAGE_META_PREFIX . 'portfolio_open', true );
			$thumb_title		= get_post_meta( $post_id, ENGAGE_META_PREFIX . 'thumb_title', true );
			$thumb_subtitle		= get_post_meta( $post_id, ENGAGE_META_PREFIX . 'thumb_sub_title', true );
			
			if ( has_post_thumbnail( $post_id ) && wp_get_attachment_url( get_post_thumbnail_id( $post_id ) ) !='' ) {	
				$thumbnail_image = get_the_post_thumbnail( $post_id );
			}
			else {				
				$thumbnail_image = '<img src="http://placehold.it/500x300"  alt="placeholder500x300">';
			}
			
			$term_string = '';
			if ( !empty( $terms ) ) {
				foreach ( $terms as $key => $value ) {
					$term_string.=' ' . $value->slug;
				}
			}
			
			if ( empty( $thumb_title ) ) {			
				$thumb_title = get_the_title();
			}			
			
			$open_in_class = 'cbp-lightbox';
			
			if ( $portfolio_open_in == 'page' ) {
				$open_in_class = 'cbp-singlePage';
			}
			
			$portfolio_url = '';
			$image_gallery = '';
			
			if ( $portfolio_type == 'video' && $portfolio_open_in == 'lightbox' ) {
				
				$video = get_post_meta( $post_id, ENGAGE_META_PREFIX . 'video_url', true );						
				$portfolio_url = $video;				
				
			}
			elseif( $portfolio_type == 'audio' && $portfolio_open_in == 'lightbox' ) {
				
				$audio = get_post_meta( $post_id, ENGAGE_META_PREFIX . 'audio_url', true );						
				$portfolio_url = 'https://w.soundcloud.com/player/?url='.$audio.'&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true';				
				
			}
			elseif( $portfolio_type == 'image' && $portfolio_open_in == 'lightbox' ) {
				
				$images_array = get_post_meta( $post_id, ENGAGE_META_PREFIX . 'image_url', false );	
				
				foreach ( $images_array as $image ) {
					$portfolio_url = wp_get_attachment_image_src( $image, '' );		
					$portfolio_url = $portfolio_url[0];
				}
				
			}
			elseif( $portfolio_type == 'gallery' && $portfolio_open_in == 'lightbox' ) {				
				
				$image_gallery = 'data-cbp-lightbox=gallary';
				$images_array = get_post_meta( $post_id, ENGAGE_META_PREFIX . 'gallery_images', false );		
				
				foreach ( $images_array as $image ) {
					$portfolio_url = wp_get_attachment_image_src( $image, '' );
					$portfolio_url = $portfolio_url[0];
				}
			}
			else {
				
				$portfolio_url = 'portfolio/'. str_replace( " ", "-", $post->post_name );
				
			}		
			
			
			?>
			
				<div class="cbp-item <?php echo esc_attr( $term_string ); ?>" >
			
					<a class="cbp-caption <?php echo esc_attr( $open_in_class ); ?>" data-title="<?php echo esc_attr( $thumb_title ); ?>"  href="<?php echo engage_strip_url( esc_url( $portfolio_url ), $portfolio_open_in ); ?>" <?php echo esc_attr( $image_gallery ); ?>>
						<div class="cbp-caption-defaultWrap"> 					
							<?php echo $thumbnail_image; ?>							
						</div>
					<div class="cbp-caption-activeWrap">
						<div class="cbp-l-caption-<?php echo esc_attr( $text_align ); ?>">
							<div class="cbp-l-caption-body">		
								<div class="cbp-l-caption-title <?php echo esc_attr( $use_theme_color_class ); ?>"><?php echo esc_html( $thumb_title ); ?></div>
								<div class="cbp-l-caption-desc"><?php echo esc_html( $thumb_subtitle ); ?></div>
							</div>
						</div>
					</div>
					</a>
			
			<?php
			
			if( $portfolio_type == 'gallery' && $portfolio_open_in == 'lightbox' ) {
				
				$images_array = get_post_meta( $post_id, ENGAGE_META_PREFIX . 'gallery_images', false );		
				foreach ( $images_array as $image ) {
					$image_url = wp_get_attachment_image_src( $image, '' ); 
					$image_url = $image_url[0]; 
					?>
					<a href="<?php echo esc_url( $image_url ); ?>" class="cbp-lightbox" data-cbp-lightbox="gallary"></a>
				<?php	
				}
				
			} ?>

            </div>
		<?php  } ?>
		
		</div><!--End #grid-container-->
		
		<?php		
		
		}
		else {
		?>
		
		<div><h1 class="err-msg"><?php esc_html_e( 'No portfolio added, Please add from admin.', 'engage' ); ?></h1></div>
		<?php
		}

		wp_reset_query();
		
		// Return outbut buffer
		return ob_get_clean();		
	}
	
	function shortcode_vcmap() {
		
		vc_map( array(
			"name"						=> esc_html__( "Portfolio Grid", 'engage' ),
			"description"				=> esc_html__( "Recent portfolio posts grid.", 'engage' ),
			"base"						=> "engage_portfolio_grid",
			"category"					=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"						=> "engage-portfolio-grid-icon",
			"params"					=> array(			
				array(
					"type"				=> "dropdown",
					"heading"			=> esc_html__( 'Grid Column', 'engage' ),
					"admin_label"		=> true,
					"param_name"		=> "grid_columns",					
					"value"				=> array(
											esc_html__( '2 Column', 'engage')   => '2',
											esc_html__( '3 Column', 'engage')   => '3',
											esc_html__( '4 column', 'engage' )  => '4',
											),
					"description"		=> esc_html__("Set how many portfolio items would you like to show in one row.", 'engage')
				),
				array(
					"type"				=> "textfield",
					"admin_label"		=> true,					
					"heading"			=> esc_html__("Number of Items", 'engage'),
					"param_name"		=> "posts_per_page",
					"value"				=> "9",
					"description"		=> esc_html__("Set how many portfolio items would you like to include in the grid.", 'engage')
				),					
				array(
					"type"				=> "dropdown",					
					"heading"			=> esc_html__( "Title Caption", 'engage' ),
					"param_name"		=> "caption",
					"value"				=> array(
											esc_html__( 'pushTop', 'engage' )			 => 'pushTop',
											esc_html__( 'revealBottom', 'engage' )		 => 'revealBottom',
											esc_html__( 'moveRight', 'engage' )			 => 'moveRight',
											esc_html__( 'overlayBottomPush', 'engage' )   => 'overlayBottomPush',                        
											esc_html__( 'overlayBottom', 'engage' )		 => 'overlayBottom',                        
											esc_html__( 'overlayBottomReveal', 'engage' ) => 'overlayBottomReveal',                        
											esc_html__( 'overlayBottomAlong', 'engage' )  => 'overlayBottomAlong',                        
											esc_html__( 'overlayRightAlong', 'engage' )   => 'overlayRightAlong',                        
											esc_html__( 'minimal', 'engage' )			 => 'minimal',                        
											esc_html__( 'fadeIn', 'engage' )			     => 'fadeIn',                        
											esc_html__( 'zoom', 'engage' )				 => 'zoom',                   
											),
					"description"		=> esc_html__( 'Portfolio Item Title Caption.', 'engage' ),					
				),
				array(
					"type"				=> "checkbox",
					"heading"			=> esc_html__( 'Use Theme Color for Title', 'engage' ),
					"param_name"		=> "use_theme_color",
					"value"				=> array(
											esc_html__( 'Yes', 'engage' )	=> 'yes',
											),
					"description"		=> esc_html__( " Check it to Apply theme color to title.", 'engage' ),					
				),
				array(
					"type"				=> "dropdown",					
					"heading"			=> esc_html__("Text Align", 'engage'),
					"param_name"		=> "text_align",
					"value"				=> array(
											esc_html__('Left', 'engage')	   => 'alignLeft',											
											esc_html__('Center', 'engage')  => 'alignCenter'
											),				
					"description"		=> esc_html__( 'Portfolio Item Title align.', 'engage' ),	
				),
				array(
					"type"				=> "dropdown",				
					"heading"			=> esc_html__("Order", 'engage'),
					"param_name"		=> "order",
					"value"				=> array(
											esc_html__('Asc', 'engage')	=>	'asc',
											esc_html__('Desc', 'engage')	=>	'desc'
											),				
				),				
				array(
					"type"				=> "textfield",				
					"heading"			=> esc_html__( "Horizontal Space", 'engage' ),
					"param_name"		=> "horizontal_space",
					"value"				=> "40",
					"description"		=> esc_html__('Horizontal space between portfolio items, Example 40.','engage'),
					"group"				=> esc_html__( 'Spacing', 'engage' ),
				),
				array(
					"type"				=> "textfield",				
					"heading"			=> esc_html__( "Vertical Space", 'engage' ),
					"param_name"		=> "vertical_space",
					"value"				=> "40",
					"description"		=> esc_html__('Vertical space between portfolio items, Example 40.','engage'),
					"group"				=> esc_html__( 'Spacing', 'engage' ),
				),			
				array(
					"type"				=> "checkbox",
					"heading"			=> esc_html__( 'Show Category Filter', 'engage' ),
					"param_name"		=> "filter",
					"value"				=> array(
											esc_html__( 'Yes', 'engage' )	=> 'yes',
											),
					"std"				=> 'yes',
					"description"		=> esc_html__( "Check to filter portfolio items by categories.", 'engage' ),					
					"group"				=> esc_html__( 'Filter', 'engage' ),
				),				
				array(
					"type"				=> "dropdown",
					"heading"			=> esc_html__( 'Filter Style', 'engage' ),
					"param_name"		=> "filter_style",					
					"value"				=> array(
											esc_html__( 'Normal', 'engage')	   => '',
											esc_html__( 'Solid', 'engage')	   => 'cbp-filter-item-active-bg',	
											esc_html__( 'Outlined', 'engage' )  => 'cbp-filter-item-active-outlined',											
											),
					"dependency"		=> array(
											'element'	=> 'filter',
											'not_empty' => true,
										   ),
					"group"				=> esc_html__( 'Filter', 'engage' ),
				),
				array(
					"type"				=> "dropdown",
					"heading"			=> esc_html__( 'Filter Align', 'engage' ),
					"param_name"		=> "filter_align",
					"value"				=> array(											
											esc_html__( 'Right', 'engage')	=> 'alignRight',
											esc_html__( 'Center', 'engage')	=> 'alignCenter',
											),
					"dependency"		=> array(
											'element'	=> 'filter',
											'not_empty' => true,
											),
					"group"				=> esc_html__( 'Filter', 'engage' ),
				),
				array(
					"type"				=> "checkbox",
					"heading"			=> esc_html__( 'Filter Counter', 'engage' ),
					"param_name"		=> "filter_counter",
					"value"				=> array(
											 esc_html__( 'Yes', 'engage' )	=> 'yes',
											),
					"description"		=> esc_html__( "Check to show count of items in filter categories.", 'engage' ),					
					"dependency"		=> array(
											'element'	=> 'filter',
											'not_empty' => true,
											),
					"group"				=> esc_html__( 'Filter', 'engage' ),
				),								
				array(
					"type"				=> "dropdown",					
					"heading"			=> esc_html__( "Animation", 'engage' ),
					"param_name"		=> "filter_animation",
					"value"				=> array(
											esc_html__( 'fadeOut', 'engage' ) => 'fadeOut',
											esc_html__( 'quicksand', 'engage' ) => 'quicksand',
											esc_html__( 'bounceLeft', 'engage' ) => 'bounceLeft',
											esc_html__( 'bounceTop', 'engage' ) => 'bounceTop',
											esc_html__( 'bounceBottom', 'engage' ) => 'bounceBottom',
											esc_html__( 'moveLeft', 'engage' ) => 'moveLeft',
											esc_html__( 'slideLeft', 'engage' ) => 'slideLeft',
											esc_html__( 'fadeOutTop', 'engage' ) => 'fadeOutTop',
											esc_html__( 'sequentially', 'engage' ) => 'sequentially',
											esc_html__( 'skew', 'engage' ) => 'skew',
											esc_html__( 'slideDelay', 'engage' ) => 'slideDelay',
											esc_html__( '3dFlip', 'engage' ) => '3dFlip',
											esc_html__( 'rotateSides', 'engage' ) => 'rotateSides',
											esc_html__( 'flipOutDelay', 'engage' ) => 'flipOutDelay',
											esc_html__( 'flipOut', 'engage' ) => 'flipOut',
											esc_html__( 'unfold', 'engage' ) => 'unfold',
											esc_html__( 'foldLeft', 'engage' ) => 'foldLeft',
											esc_html__( 'scaleDown', 'engage' ) => 'scaleDown',
											esc_html__( 'scaleSides', 'engage' ) => 'scaleSides',
											esc_html__( 'frontRow', 'engage' ) => 'frontRow',
											esc_html__( 'flipBottom', 'engage' ) => 'flipBottom',
											esc_html__( 'rotateRoom' , 'engage' ) => 'rotateRoom',
											),
					"description"		=> esc_html__( 'Animation for filtering of portfolio items based on categories selected.', 'engage' ),
					"dependency"		=> array(
											'element'	=> 'filter',
											'not_empty' => true,
											),
					"group"				=> esc_html__( 'Filter', 'engage' ),				
				),		
			),
		) );
	}
}

new Engage_Portfolio_Grid();