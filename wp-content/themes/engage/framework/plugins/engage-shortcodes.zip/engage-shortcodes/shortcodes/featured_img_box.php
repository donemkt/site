<?php
/**
 * Registers the featured image box shortcode and adds it to the Visual Composer
 */

class Engage_Featured_Img_Box {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_featured_img_box', array( $this, 'shortcode' ) );
		
	}	
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_featured_img_box', $atts ) );
		
		ob_start();
		
		$image = wp_get_attachment_image_src( $img_src, array( 400, 300 ) );
		if ( isset($image[0]) && $image[0] ){
			$featured_image = '<img src="'.$image[0].'" class="img-responsive" alt="'.$title.'" />';
		} else {
	        $featured_image = '<img src="http://placehold.it/400x300"  class="img-responsive" alt="placeholder400x300">';
		}
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		//Background Color
		$bgcolor_style = '';
		if ( $bg_color ) {	
			$bgcolor_style = 'background-color:'. $bg_color .';';
		}	

		if ( $bgcolor_style ) {
			$bgcolor_style = ' style="' . esc_attr( $bgcolor_style ) . '"';
		}
		
		
		//overlay Color
		$overlay_style = '';
		if ( $overlay_color ) {	
			$overlay_style = 'background-color:'. $overlay_color .';';
		}	

		if ( $overlay_style ) {
			$overlay_style = ' style="' . esc_attr( $overlay_style ) . '"';
		}	
		
		?>

		<?php if ( $imagebox_style == 'effect-milo' || $imagebox_style == 'effect-oscar' ) { ?>
			<div class="fancy-box grid <?php echo esc_attr( $animation_class ); ?>" <?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
				<figure class="<?php echo esc_attr( $imagebox_style ); ?>" <?php echo $bgcolor_style; ?>> 					
					<?php echo $featured_image; ?>
					<figcaption <?php echo $overlay_style; ?>>
						<div>
							<h2><?php echo esc_html( $title ); ?></h2>
							
							<?php if ( $desc ) { ?>
							<p><?php echo esc_html( $desc ); ?></p>
							<?php } ?>
							
						</div>
					</figcaption>	
				</figure>
			</div>
		
		<?php } 
		else {	?>		
			<div class="featured-img-box <?php echo esc_attr( $imagebox_style ); ?> <?php echo esc_attr( $animation_class ); ?>" 
							<?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?> <?php echo $bgcolor_style; ?>>
				<figure>
					<?php echo $featured_image; ?>
				</figure>
				<div class="fimg-box-desc">

					<?php if ( $imagebox_style == 'has-icon' ) { ?>
					
						<?php if ( $icon_type == 'fontawesome' ) { ?>
							<span class="fimg-box-icon theme-bg-color <?php echo esc_attr( $icon_fontawesome ); ?>"> </span>
						<?php } else {	?>
							<span class="fimg-box-icon theme-bg-color <?php echo esc_attr( $icon_ionicons ); ?>"> </span>
						<?php } ?>		
							
					<?php } ?>	

					<h4 class="thumbnail-box-title"><?php echo esc_html( $title ); ?></h4>
					<p><?php echo esc_html( $desc ); ?></p>
				</div>
			</div>
		<?php } ?>


		<?php
		
		// Return outbut buffer
		return ob_get_clean();		
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Featured Image Box", 'engage' ),
			"description"			=> esc_html__( "Add featured image box with content.", 'engage' ),
			"base"					=> "engage_featured_img_box",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"					=> "engage-featured-img-box-icon",
			"params"				=> array(
				array(
					"type"			=> "dropdown",
					"admin_label"	=> true,
					"heading"		=> esc_html__( 'Image Box Style', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "imagebox_style",
					"value"         => array(
											esc_html__( "Image Box", 'engage' )					   => "",
											esc_html__( "Image Box with Icon", 'engage' )		   => "has-icon",																						
											esc_html__( "Image Box with hover effect", 'engage' )  => "effect-oscar",											
									    ),
				),
				array(
					"type"			=> "textfield",
					"admin_label"	=> true,
					"heading"		=> esc_html__( 'Title', 'engage' ),
					"param_name"	=> "title",
					"value"			=> "Unique Design"
				),
				array(
					"type"			=> "textarea",					
					"heading"		=> esc_html__( "Description", 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "desc",
					"value"			=> esc_html__( 'Don\'t forget to change this dummy text.', 'engage' )
				),
				array(
					"type"			=> "attach_image",					
					"heading"		=> esc_html__('Image', 'engage' ),
					"param_name"	=> "img_src",
					"value"			=> "",
					"description"	=> esc_html__("Attached Featured Image.", 'engage')
				),					
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Background Color', 'engage' ),
					"param_name"	=> "bg_color",
					"dependency"	=> array(
										'element'	=> 'imagebox_style',
										'value'	    => array ( 'has-icon', 'effect-milo', 'effect-oscar' ),
										),					
				),
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Overlay Color', 'engage' ),
					"param_name"	=> "overlay_color",
					"dependency"	=> array(
										'element'	=> 'imagebox_style',
										'value'	    => array ( 'effect-milo', 'effect-oscar' ),
										),					
				),						
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Icon library', 'engage' ),
					'value'			=> array(						
										esc_html__( 'Ion Icons', 'engage' ) => 'ionicons',
										esc_html__( 'Font Awesome', 'engage' ) => 'fontawesome',						
										),
					'param_name'	=> 'icon_type',
					"dependency"	=> array(
										'element'	=> 'imagebox_style',
										'value'	    => 'has-icon',
										),
					'description'	=> esc_html__( 'Select icon library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_fontawesome',
					'value'			=> 'fa fa-bicycle',
					'settings'		=> array(
										'emptyIcon' => false,
										// default true, display an "EMPTY" icon?
										'iconsPerPage' => 4000,
										// default 100, how many icons per/page to display
									   ),
					'dependency'	=> array(
										'element' => 'icon_type',
										'value' => 'fontawesome',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_ionicons',
					'value'			=> 'ion-cube',
					'settings'		=> array(
										'emptyIcon' => false, // default true, display an "EMPTY" icon?
										'type'		=> 'ionicons',
										'source'	=> engage_iconpicker_type_ionicons(),
										),
					'dependency'	=> array(
										'element'	=> 'icon_type',
										'value'		=> 'ionicons',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					'value'         => array(
										esc_html__( 'None', 'engage' )      => '',                      
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',	                   
									  ),
					"description"	=> esc_html__( 'Animation Effect for feature box.', 'engage' ),
					'group'			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Featured_Img_Box();