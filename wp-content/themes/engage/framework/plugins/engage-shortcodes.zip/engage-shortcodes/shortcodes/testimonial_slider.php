<?php
/**
 * Registers the testimonials slider shortcode and adds it to the Visual Composer 
 */

class Engage_Testimonial_Slider {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_testimonial_slider', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_testimonial_slider', $atts ) );
		
		ob_start();	
		
		$data_attr  = '';
		$data_attr .= ( $navigation )        ? ' data-nav = true '								   : '';		
		$data_attr .= ( $navigation && 
						$navigation_speed )  ? ' data-navspeed = '.intval( $navigation_speed )	   : '';				
		$data_attr .= ( $pagination )		 ? ' data-dots = true '								   : '';		
		$data_attr .= ( $pagination &&
						$pagination_speed )  ? ' data-dotsspeed = '.intval( $pagination_speed )	   : '';		
		$data_attr .= ( $auto_play )		 ? ' data-autoplay = true '							   : '';			
		$data_attr .= ( $auto_play &&
						$slideshow_speed )   ? ' data-autoplayspeed = '.intval( $slideshow_speed ) : '';
		$data_attr .= ( $auto_play &&
						$hover_pause )		 ? ' data-stoponhover = true '						   : '';
		$data_attr .= ( $auto_play &&
						$infinite_loop )	 ? ' data-loop = true '								   : '';		
		
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if ( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		?>
		
		<div class="testimonials <?php echo esc_attr( $testimonial_style ); ?> <?php echo esc_attr( $pagination_style ); ?> <?php echo esc_attr( $animation_class ); ?>" 
			<?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
			 
			<?php if ( $testimonial_style != 'left-aligned has-image' && $title) { ?>
			<h3><?php echo esc_html( $title ); ?></h3>
			<?php } ?>
			 
            <div class="golo-carousel" <?php echo $data_attr; ?>> 
			<?php
		
			$slider_content = (array) vc_param_group_parse_atts( $slider_content );

			foreach ( $slider_content as $data ) {

				$author			= !empty( $data['author'] )		 ? $data['author']		: 'James Hall';
				$img_src		= !empty( $data['img_src'] )	 ? $data['img_src']		: '';
				$position		= !empty( $data['position'] )	 ? $data['position']	: 'Business Man';
				$testimonial	= !empty( $data['testimonial'] ) ? $data['testimonial'] : 'Etiam ac diam ut est sagittis porttitorlum nisl metus ligula vehicula.';
				
				$author_image = '';
				if ( !empty( $img_src ) ) {					
				
					$image = wp_get_attachment_image_src( $img_src, array( 260, 265 ) );
						
					if ( isset($image[0]) && $image[0] ) {
						$author_image = '<img src="'.$image[0].'" class="img-responsive img-circle" alt="'.esc_attr( $title ).'" />';
					} else {
						$author_image = '<img src="http://placehold.it/260x265"  class="img-responsive img-circle" alt="placeholder260x265">';
					}			
				}
			?>  
			<?php if ( $testimonial_style == 'left-aligned has-image' ) { ?>
				
				<div>
                    <div class="vc_col-sm-3">
                        <div class="author-img">
                            <?php echo $author_image; ?>
                        </div>
                    </div>
					<div class="vc_col-sm-9">
			
			<?php } ?>
					
				<div class="slider-content">													
						
					<img src="<?php echo ENGAGE_IMAGE_URL; ?>/others/quote.png" alt=""/>				
					
					<?php if ( $testimonial_style == 'center-aligned' && $author_image ) { ?>
					
                    <div class="author-img">
                       <?php echo $author_image; ?>
                    </div>	

					<?php } ?>
					
                    <p><?php echo esc_html( $testimonial ); ?></p>					
                    <h4><?php echo esc_html( $author ); ?></h4>
                    <div><?php echo esc_html( $position ); ?></div>
                </div>
					
				<?php if ( $testimonial_style == 'left-aligned has-image' ) { ?>			
					</div>
                </div>		
				<?php } ?>
			<?php	
			}
		?>
			</div>
		</div>

		<?php
		
		// Return outbut buffer
		return ob_get_clean();	
		
		
	}
	
	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Testimonials Slider", 'engage' ),
			"description"			=> esc_html__( "Add testimonials slider", 'engage' ),
			"base"					=> "engage_testimonial_slider",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"					=> "engage-testimonial-slider-icon",			
			"params"				=> array(
				array(
					"type"			=> "dropdown",
					"admin_label"	=> true,
					"heading"		=> esc_html__( 'Testimonial Slider Style', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "testimonial_style",
					"value"         => array(
											esc_html__( "Center aligned with image", 'engage' )		=> "center-aligned",
											esc_html__( "Center aligned without image", 'engage' )	=> "center-aligned no-image",
											esc_html__( "Left aligned with image", 'engage' )		=> "left-aligned has-image",											
											esc_html__( "Left aligned without image", 'engage' )	=> "left-aligned",											
									    ),
				),				
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Testimonial Heading", 'engage' ),
					"param_name"	=> "title",				
					"dependency"	=> array(
											'element' => 'testimonial_style',
											'value'	  => array ( 'left-aligned', 'center-aligned', 'center-aligned no-image' ),
										)					
				),
				array(
					"type"			=> "param_group",
					"heading"		=> esc_html__( 'Slider Content', 'engage' ),
					"param_name"	=> "slider_content",					
					"description"	=> esc_html__( 'Enter Testimonial Data.', 'engage' ),
					"value"			=> urlencode( json_encode( array(
										array(
											'author'		=> 'James Hall1',
											'position'		=> 'Business Man',
											'testimonial'	=> 'Etiam ac diam ut est sagittis porttitorlum nisl metus ligula vehicula.',
										),
										array(
											'author'		=> 'James Hall2',
											'position'		=> 'Business Man',
											'testimonial'	=> 'Etiam ac diam ut est sagittis porttitorlum nisl metus ligula vehicula.',
										),
										array(
											'author'		=> 'James Hall3',
											'position'		=> 'Business Man',
											'testimonial'	=> 'Etiam ac diam ut est sagittis porttitorlum nisl metus ligula vehicula.',
										),
										) ) ),					
					"params"		=> array(
											array(
												"type"			=> "textfield",												
												"heading"		=> esc_html__("Author Name", 'engage'),
												"param_name"	=> "author",
												"value"			=> "James Hall",
											),
											array(
												"type"			=> "textfield",
												"heading"		=> esc_html__("Author company/position", 'engage'),												
												"param_name"	=> "position",
												"value"			=> "Business Man",
											),
											array(
												"type"			=> "textarea",
												"heading"		=> esc_html__("Tetimonial Text", 'engage'),												
												"param_name"	=> "testimonial",
												"value"			=> "Etiam ac diam ut est sagittis porttitorlum nisl metus ligula vehicula.",
											),
											array(
												"type"			=> "attach_image",					
												"heading"		=> esc_html__("Author Image", 'engage'),
												"param_name"	=> "img_src",
												"dependency"	=> array(
																	 'element'	=> 'testimonial_style',
																	 'value'	=> array ( 'center-aligned', 'left-aligned has-image' ),
																	),
												"value"			=> "",
												"description"	=> esc_html__("Attached Author Image.", 'engage')
											),
										),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Auto Play", 'engage' ),
					"param_name"	=> "auto_play",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes'
									   ),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Slideshow speed", 'engage' ),
					"param_name"	=> "slideshow_speed",
					"description"	=> esc_html__( 'Choose slideshow speed (in milliseconds)', 'mthemes' ),
					"value"			=> "1000",
					"dependency"	=> array(
											'element' => 'auto_play',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Infinite Loop", 'engage' ),
					"param_name"	=> "infinite_loop",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes',
										),
					"dependency"	=> array(
											'element' => 'auto_play',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Pause slideshow", 'engage' ),
					"description"	=> esc_html__( "Pause slideshow when you hover over slide image", 'engage' ),
					"param_name"	=> "hover_pause",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes',
										),
					"dependency"	=> array(
											'element'   => 'auto_play',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Show Pagination", 'engage' ),
					"description"	=> esc_html__( "Choose to show slider pagination", 'engage' ),
					"param_name"	=> "pagination",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes'
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Pagination style", 'engage' ),
					"param_name"	=> "pagination_style",
					"value"         => array(
										esc_html__( 'Square Dot', 'engage' )    => 'square-dot',									
										esc_html__( 'Circle Dot', 'engage' )    => 'circle-dot'                        
										),
					"dependency"	=> array(
											'element' => 'pagination',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Pagination speed", 'engage' ),
					"param_name"	=> "pagination_speed",
					"description"	=> esc_html__( 'Choose pagination speed (in milliseconds)', 'engage' ),
					"value"			=> "1000",
					"dependency"	=> array(
											'element' => 'pagination',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Show Navigation", 'engage' ),
					"description"	=> esc_html__( "Choose to show slider navigation", 'engage' ),
					"param_name"	=> "navigation",
					"value"			=> array(
											esc_html__( 'Yes', 'engage' ) => 'yes'
										),
					"dependency"	=> array(
										'element'	=> 'testimonial_style',
									    'value'		=> array ( 'center-aligned', 'center-aligned no-image' ),
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Navigation speed", 'engage' ),
					"param_name"	=> "navigation_speed",
					"description"	=> esc_html__( 'Choose navigation speed (in milliseconds)', 'engage' ),
					"value"			=> "1000",
					"dependency"	=> array(
											'element' => 'navigation',
											'not_empty' => true,
										),
					"group"			=> esc_html__( 'Slider Settings', 'engage' ),
				),			
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"			=> array(
											esc_html__( 'None', 'engage' ) => '',
											esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
											esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
											esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
											esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
											esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
											esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
											esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
											esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
											esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
											esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
											esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
											esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
											esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
											esc_html__( 'flipInX', 'engage' ) => 'flipInX',
											esc_html__( 'flipInY', 'engage' ) => 'flipInY',
											esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
											esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
											esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
											esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
											esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
											esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
											esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
											esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
											esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
											esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
											esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
											esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
											esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
											esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
											esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
											esc_html__( 'rollIn', 'engage' ) => 'rollIn',
										),
					"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",
					"description"	=> esc_html__( 'Animation Delay Timming.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",
					"description"	=> esc_html__( 'Animation Duration Timming.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
			),			
		) );
	}
}

new Engage_Testimonial_Slider();