<?php
/**
 * Registers the icon box shortcode and adds it to the Visual Composer
 */

class Engage_Video_Modal {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_video_modal', array( $this, 'shortcode' ) );
		
	}	
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_video_modal', $atts ) );
		
		ob_start();	
		
		$background_style = '';
		
		if ( $use_bg_color == 'yes' && $bg_color ) {	
			$background_style .= 'background-color:'. $bg_color .';';
		}
		else if ( $use_bg_image == 'yes' ) { //Background Image
			
			if ( $bg_image ) {	
				
				$bg_img_url = wp_get_attachment_url( $bg_image );			
				$background_style .= 'background-image: url('. esc_url( $bg_img_url ) .');';
			}	
			else {
				$background_style .= 'background-image: url(http://placehold.it/1920x980);';
			}			
		}
		
		//Padding
		if ( $padding_top ) {	
			$background_style	.= 'padding-top:'. $padding_top .';';
		}

		if ( $padding_bottom ) {	
			$background_style	.= 'padding-bottom:'. $padding_bottom .';';
		}
		
		//Background style
		if ( $background_style ) {
			$background_style = ' style="' . esc_attr( $background_style ) . '"';
		}
		
		$icon_bg_color_style = '';
		$use_icon_bg_theme_color_class = '';
		
		if ( $use_icon_bg_theme_color ) {
			$use_icon_bg_theme_color_class = 'theme-bg-color';			
		}
		elseif ( $icon_bg_color ) {	
			$icon_bg_color_style = 'background-color:'. $icon_bg_color .';';
		}	

		if ( $icon_bg_color_style ) {
			$icon_bg_color_style = ' style="' . esc_attr( $icon_bg_color_style ) . '"';
		}
		
		//Icon Color
		$icon_style = '';
		$icon_theme_color_class = '';		
		
		if ( $icon_use_theme_color ) {
			$icon_theme_color_class = 'theme-color';					
		}
		elseif ( $icon_color ) {	
			$icon_style = 'color:'. $icon_color .';';
		}	

		if ( $icon_style ) {
			$icon_style = ' style="' . esc_attr( $icon_style ) . '"';
		}
		
		//Title Color 
		$title_style = '';
		if ( $title_color ) {	
			$title_style = 'color:'. $title_color .';';
		}	

		if ( $title_style ) {
			$title_style = ' style="' . esc_attr( $title_style ) . '"';
		}
		
		
		?>		

		<div class="modal-popup clearfix" <?php echo $background_style; ?>>
			<a href="<?php echo esc_url( $video_url ); ?>" class="modal-popup-video">
				<div class="play-icon <?php echo esc_attr( $use_icon_bg_theme_color_class ); ?>" <?php echo $icon_bg_color_style; ?>>
					<i class="ion-ios-play-outline <?php echo esc_attr( $icon_theme_color_class ); ?>" <?php echo $icon_style; ?>></i>
				</div>
			</a>
			<?php if ( $video_title ) { ?>
				<div class="caption" <?php echo $title_style; ?>><?php echo esc_html( $video_title ); ?></div>
			<?php } ?>
		</div>      
        		
		<?php
		
		// Return outbut buffer
		return ob_get_clean();		
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Video Modal", 'engage' ),
			"description"			=> esc_html__( "Add Video Modal Popup", 'engage' ),
			"base"					=> "engage_video_modal",
			"icon" 					=> "engage-video-modal-icon",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"params"				=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Video URL', 'engage' ),
					'param_name'	=> 'video_url',
					'admin_label'	=> true,
					'description'	=> esc_html__( 'URL link to the video.Video will be open in modal popup.', 'engage' ),						
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Title", 'engage' ),									
					"param_name"	=> "video_title",					
					"description"	=> esc_html__('Enter Title for Video.','engage'),
				),
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Title', 'engage' ),
					"param_name"	=> "title_color",				
					"value"			=> "#ffffff",
					"description"	=> esc_html__("Choose Color for Title", 'engage'),					
				),		
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Icon", 'engage' ),
					"param_name"	=> 'icon_use_theme_color',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),					
					"description"	=> esc_html__("Check it to Apply theme color to Icon", 'engage'),					
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Icon', 'engage' ),
					"param_name"	=> "icon_color",				
					"value"			=> "#ffffff",
					"description"	=> esc_html__("Choose Color for Icon", 'engage'),					
				),							
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Icon Background", 'engage' ),
					"param_name"	=> 'use_icon_bg_theme_color',
					"description"	=> esc_html__('Check it to Apply theme color to Icon Background.','engage'),
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),										
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Icon Background', 'engage' ),
					"param_name"	=> "icon_bg_color",
					"description"	=> esc_html__('Choose Color for Icon Background.','engage'),
					"dependency"	=> array(
										'element'	=> 'use_icon_bg_theme_color',
										'is_empty'	=> true,
										),		
					"value"			=> "#ffffff",
				),												
				array(
					'type'			=> 'checkbox',
					'heading'		=> esc_html__( "Use Color Background", 'engage' ),
					'param_name'	=> 'use_bg_color',
					'value'			=> array(
										esc_html__( "Yes", 'engage' ) => 'yes'
										),
					'description'	=> esc_html__( "If checked, color will be used in background, will drop image selection", 'engage' ),
					'group'			=> esc_html__( 'Background', 'engage' ),
				),
				array(
					'type'			=> 'colorpicker',
					'heading'		=> esc_html__( 'Color', 'engage' ),
					'param_name'	=> 'bg_color',
					'group'			=> esc_html__( 'Background', 'engage' ),
					'dependency'    => array(
											'element'   => 'use_bg_color',
											'not_empty' => true,
										),
					),
				array(
					'type'			=> 'checkbox',
					'heading'		=> esc_html__( "Use Image Background", 'engage' ),
					'param_name'	=> 'use_bg_image',
					'value'			=> array(
										esc_html__( "Yes", 'engage' ) => 'yes'
										),	
					'description'	=> esc_html__( "If checked, image will be used in background.", 'engage' ),
					'group'			=> esc_html__( 'Background', 'engage' ),	
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__( 'Image', 'engage' ),
					'param_name'	=> 'bg_image',
					'description'	=> esc_html__( 'Select image from media library.', 'engage' ),	
					'dependency'    => array(
											'element'   => 'use_bg_image',
											'not_empty' => true,
										),
					'group'			=> esc_html__( 'Background', 'engage' ),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Padding Top', 'engage' ),
					'param_name'	=> 'padding_top',
					'group'			=> esc_html__( 'Padding', 'engage' ),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Padding Bottom', 'engage' ),
					'param_name'	=> 'padding_bottom',
					'group'			=> esc_html__( 'Padding', 'engage' ),
				),

			)
		) );
	}
}

new Engage_Video_Modal();