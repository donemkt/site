<?php
/**
 * Registers the team member shortcode and adds it to the Visual Composer 
 */

class Engage_Team_Member {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_team_member', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_team_member', $atts ) );
		
		ob_start();	
				
		$image = wp_get_attachment_image_src( $img_src, array( 438, 448 ) );
		if ( isset($image[0]) && $image[0] ){
			$member_image = '<img src="'.$image[0].'" alt="'.$member_name.'" class="img-responsive"/>';
		} else {
	        $member_image = '<img src="http://placehold.it/438x448"  alt="placeholder438x448">';
		}
		
		$icon_arr = array( 'facebook', 'twitter', 'linkedin', 'google-plus' );    
	    $socials = '';

        foreach ( $icon_arr as $icon_name ) {
			if ( isset( $atts[$icon_name] ) ) {		
				$socials .= '<a href="'.esc_url( $atts[$icon_name] ).'" class="social-icon"><i class="fa fa-'.esc_attr( $icon_name ).'"></i></a>';				
			}
		}		
	
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if ( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		// Give team member id a unique name
		$rand_num = rand( 1, 1000 );
		$unique_member_id = 'member-' . strtolower( str_replace( ' ', '', $member_name ) ) . $rand_num;
		
		$darkbg_class = '';		
		if ( $dark_bg ) {
			$darkbg_class = 'dark-bg';
		}
		
		$haspopup_class = '';		
		if ( $team_popup ) {
			$haspopup_class = 'has-popup';
		}
		
		$hasanimation_class = '';
		if( $animation_flipup ) {
			$hasanimation_class = 'has-animation';
		}
		
		?>
		
		<div class="team <?php echo esc_attr( $hasanimation_class ); ?> <?php echo esc_attr( $haspopup_class ); ?> <?php echo esc_attr( $animation_class ); ?>" 
				<?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
			
		<?php if( $animation_flipup ) { ?>
			<div class="team-wrap">
		<?php } ?>	
				
				<div class="team-image">
					<?php echo $member_image; ?>
					<?php if ( $team_popup ) { ?>
						<div class="team-popup">
							<a class="plus html-popup" href="#<?php echo $unique_member_id; ?>"> 
								<span class="icon ion-ios-plus-empty"></span> 
							</a>
						</div>				
					<?php } ?>
				</div>
				
			<?php if( $animation_flipup ) { ?>		
				<div class="team-desc-wrap">
			<?php } ?>		
					
					<div class="team-desc <?php echo esc_attr( $darkbg_class ); ?> align-<?php echo esc_attr( $align_text ); ?>">
						<div class="team-title">
							<h4><?php echo esc_html( $member_name ); ?></h4>
							<span><?php echo esc_html( $position );  ?></span>
						</div>
						<?php if ( $show_socials == '' ) { ?>
							<?php echo $socials; ?>
						<?php } ?>
					</div>
			
			<?php if( $animation_flipup ) { ?>		
				</div>
			<?php } ?>
				
		<?php if( $animation_flipup ) { ?>		
			</div>
		<?php } ?>	
		</div>

		<?php if ( $team_popup ) { ?>

			<div id="<?php echo $unique_member_id; ?>" class="container mfp-hide">
				<div class="vc_row">
					<div class="member-details vc_col-lg-10 vc_col-lg-offset-1 no-padding">
						<div class="vc_row">
							<button title="Close (Esc)" type="button" class="ion-ios-close-empty mfp-close"></button>
							<div class="vc_col-md-5 vc_col-lg-5 no-padding">			
								<?php echo $member_image; ?>
							</div>
							<div class="vc_col-md-7 vc_col-lg-7 padd25">
								<h3><?php echo esc_html( $member_name ); ?></h3>
								<p class="lead"><?php echo esc_html( $position ); ?></p>
								
								<?php if ( $socials ) { ?>
								<div class="popup-socials">
									<?php echo $socials; ?>
								</div>
								<?php } ?>
								<div class="content member-skills">
								<p><?php echo esc_html( $desc );?></p>						
									<div class="progress-wrapper">		
										<h5><?php echo esc_html( $title ); ?></h5>
										<div class="skills marT50">
											<ul class="skill-bar">
													
												<?php
												$values = (array) vc_param_group_parse_atts( $values );

												foreach ( $values as $data ) {

													$label = !empty( $data['label'] ) ? $data['label'] : 'Label';
													$value = !empty( $data['value'] ) ? $data['value'] : '100';

													$bar_bgcolor  = '';
													$bar_txtcolor = '';
													
													$theme_color_class = '';		
													if ( isset( $data['use_theme_color'] ) ) {			
														$theme_color_class = 'theme-bg-color';
													}
													elseif ( isset( $data['customcolor'] ) && ( ! isset( $data['color'] ) || 'custom' === $data['color'] ) ) {
														$bar_bgcolor = ' style="background-color: ' . esc_attr( $data['customcolor'] ) . ';"';
													}
													
													
													if ( isset( $data['customtxtcolor'] ) && ( ! isset( $data['color'] ) || 'custom' === $data['color'] ) ) {
														$bar_txtcolor = ' style="color: ' . esc_attr( $data['customtxtcolor'] ) . ';"';
													}
													?>

													<li class="active progress vc_col-md-5">
														<div class="skill-bar-wrap">
															<div data-width="<?php echo esc_attr( $value ); ?>" class="progress-bar <?php echo esc_attr( $theme_color_class ); ?>" data-name="<?php echo esc_attr( $label ); ?>" <?php echo $bar_bgcolor; ?>>
															<span class="skill-name" <?php echo $bar_txtcolor; ?>><?php echo esc_html( $label ); ?></span>
															<span class="percentage" <?php echo $bar_txtcolor; ?>><?php echo esc_html( $value ); ?>%</span>
															</div>
														</div>
													</li>	

													<?php
												}
												?>

											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>			
		
		<?php } ?>
		
		
		<?php

		// Return outbut buffer
		return ob_get_clean();
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Team Member", 'engage' ),
			"description"			=> esc_html__( "Add Team member", 'engage' ),
			"base"					=> "engage_team_member",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon" 					=> "engage-team-member-icon",			
			"params"				=> array(				
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Member Name", 'engage'),
					"param_name"	=> "member_name",
					"admin_label"	=> true,
					"value"			=> "JOHN DOE",
					"description"	=> esc_html__("Enter the name of team member", 'engage')
				),
				array(
					"type"			=> "textfield",				
					"heading"		=> esc_html__("Member Position", 'engage'),
					"param_name"	=> "position",
					"admin_label"	=> true,
					"value"			=> "UI Designer",
					"description"	=> esc_html__("Enter the position of team member.", 'engage')
				),				
				array(
					"type"			=> "attach_image",					
					"heading"		=> esc_html__("Avatar", 'engage'),
					"param_name"	=> "img_src",
					"value"			=> "",
					"description"	=> esc_html__("Select the image of the team member.", 'engage')
				),
				array(
					"type"			=> "dropdown",				
					"heading"		=> esc_html__("Text Alignment", 'engage'),
					"param_name"	=> "align_text",					
					"value"			=> array(						
										esc_html__( 'Center', 'engage' )	=> 'center',
										esc_html__( 'Left', 'engage' )	=> 'left',																
										),
					"description"	=> esc_html__("Choose the text alignment.", 'engage')
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Dark Text Background", 'engage' ),
					"param_name"	=> 'dark_bg',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"description"	=> esc_html__("Check for dark background and white text.", 'engage')
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Push Up Animation", 'engage' ),
					"param_name"	=> 'animation_flipup',
					"value"			=> array(								
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"dependency"	=> array(
										'element'	=> 'dark_bg',
										'is_empty'	=> true,
										),
					"description"	=> esc_html__("Check for push up animation.", 'engage')
				),			
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Show Modal Popup", 'engage' ),
					"param_name"	=> 'team_popup',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"description"	=> esc_html__("Check to show more member details in modal popup.", 'engage'),					
				),			
				array(
					"type"			=> "textarea",				
					"heading"		=> esc_html__("Description", 'engage'),
					"param_name"	=> "desc",				
					"value"			=> "Aliquam lorem ligula, lacinia nec aliquam et, elementum accumsan dui.",
					"description"	=> esc_html__("Member Description.", 'engage'),
					"dependency"	=> array(
										'element'	=> 'team_popup',
										'value'		=> 'yes',
										),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( 'Progress Bar Heading', 'engage' ),
					"param_name"	=> "title",
					"value"			=> "I AM GOOD AT",
					"description"	=> esc_html__("Enter the heading above the progress bar.", 'engage'),
					"dependency"	=> array(
										'element'	=> 'team_popup',
										'value'		=> 'yes',
									   ),
				),				
				array(
					'type'			=> 'param_group',
					'heading'		=> esc_html__( 'Progress Bar Data', 'engage' ),
					'param_name'	=> 'values',
					'description'	=> esc_html__( 'Enter data for progress bar.', 'engage' ),
					'value'			=> urlencode( json_encode( array(
											array(
												'label' => esc_html__( 'Development', 'engage' ),
												'value' => '90',
											),
											array(
												'label' => esc_html__( 'Design', 'engage' ),
												'value' => '80',
											),
											array(
												'label' => esc_html__( 'Marketing', 'engage' ),
												'value' => '70',
											),
										) ) ),
							'params' => array(
											array(
												'type' => 'textfield',
												'heading' => esc_html__( 'Label', 'engage' ),
												'param_name' => 'label',
												'description' => esc_html__( 'Enter the text for progress bar title.', 'engage' ),												
											),
											array(
												'type' => 'textfield',
												'heading' => esc_html__( 'Value', 'engage' ),
												'param_name' => 'value',
												'description' => esc_html__( 'Enter percentage value for bar.', 'engage' ),												
											),
											array(
												"type"			=> 'checkbox',
												"heading"		=> esc_html__( "Use Theme Color for Progress Bar", 'engage' ),
												"param_name"	=> 'use_theme_color',
												"value"			=> array(
																		esc_html__("Yes.", 'engage' )	=> 'yes',
																	),					
												"description"	=> esc_html__("Check it to Apply theme color to progress bar.", 'engage'),												
											),			
											array(
												'type' => 'colorpicker',
												'heading' => esc_html__( 'Use Custom Color for Progress Bar', 'engage' ),
												'param_name' => 'customcolor',
												"dependency"	=> array(
																	'element'	=> 'use_theme_color',
																	'is_empty'	=> true,
																	),
												'description' => esc_html__( 'Choose Color for progress bar.', 'engage' ),
												'value' => '#202020',
											),
											array(
												'type' => 'colorpicker',
												'heading' => esc_html__( 'Use Custom Color for Text', 'engage' ),
												'param_name' => 'customtxtcolor',
												'description' => esc_html__( 'Choose Color for progress bar text.', 'engage' ),
												'value' => '#202020',
											),
										),
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Show social icons only in modal popup", 'engage' ),
					"param_name"	=> 'show_socials',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"description"	=> esc_html__("By default social icons are shown.", 'engage'),
					"group"			=> esc_html__( 'Social Icons', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Facebook Url", 'engage'),
					"param_name"	=> "facebook",
					"value"			=> "",
					"description"	=> esc_html__("Facebook Url to contact.", 'engage'),
					"group"			=> esc_html__( 'Social Icons', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Twitter Url", 'engage'),
					"param_name"	=> "twitter",
					"value"			=> "",
					"description"	=> esc_html__("Twitter Url to contact.", 'engage'),
					"group"			=> esc_html__( 'Social Icons', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Linkedin", 'engage'),
					"param_name"	=> "linkedin",
					"value"			=> "",
					"description"	=> esc_html__("Linkedin Url to contact.", 'engage'),
					"group"			=> esc_html__( 'Social Icons', 'engage' ),
				),			
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Google Plus", 'engage'),
					"param_name"	=> "google-plus",
					"value"			=> "",
					"description"	=> esc_html__("Google plus Url to contact.", 'engage'),
					"group"			=> esc_html__( 'Social Icons', 'engage' ),
				),			
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"         => array(
											esc_html__( 'None', 'engage' )      => '',                      
											esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
											esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
											esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
											esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
											esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
											esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
											esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
											esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
											esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
											esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
											esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
											esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
											esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
											esc_html__( 'flipInX', 'engage' ) => 'flipInX',
											esc_html__( 'flipInY', 'engage' ) => 'flipInY',
											esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
											esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
											esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
											esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
											esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
											esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
											esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
											esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
											esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
											esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
											esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
											esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
											esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
											esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
											esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
											esc_html__( 'rollIn', 'engage' ) => 'rollIn',	                            
										),
					"description"	=> esc_html__( 'Animation Effect for team member.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),					
			)
		) );
	}
}

new Engage_Team_Member();