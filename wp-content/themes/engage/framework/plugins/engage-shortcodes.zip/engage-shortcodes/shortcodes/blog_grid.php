<?php
/**
 * Registers the blog grid shortcode and adds it to the Visual Composer 
 */

class Engage_Blog_Grid {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_blog_grid', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_blog_grid', $atts ) );		
		
		ob_start();
		
		// Get global var
		global $post;	
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		$blog_array_cats = get_terms( 'category', array( 'hide_empty' => false ) );
		if( empty( $categories ) ) {
			foreach( $blog_array_cats as $blog__array_cat ) {
	            $categories .= $blog__array_cat->slug .', ';
			}
		}
		
		$limit = 3;
		
		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => $limit,
			'order'          => $order,
			'orderby'        => $orderby,
			'category_name'  => $categories,
			'post_status'    => 'publish'
		);		
		
		$blog_query = new WP_Query( $args );	

		if( $blog_query ->have_posts() ) {			
		
		?>
		
		<div class="post-container clearfix">
		
		<?php 
		
		foreach ( $blog_query -> posts as $post ) {
			
			setup_postdata( $post );		
			
			// Post Vars
			$post_id		= $post -> ID;
			$format			= ( get_post_format( $post_id ) == '' ) ? 'image' : get_post_format( $post_id );
			$post_title		= get_the_title();
			$post_date		= get_the_time( 'd M Y' );			
			$link			= get_permalink();			
			$video_url		= get_post_meta( $post_id, ENGAGE_META_PREFIX . 'post_video_url', true );
			$audio_url		= get_post_meta( $post_id, ENGAGE_META_PREFIX . 'post_audio_url', true );
			$all_post_link	= '';
			$post_thumbnail = '';
			
			if( get_option( 'show_on_front' ) == 'page' ) { 
				$all_post_link = get_permalink( get_option( 'page_for_posts' ) );
			}
			else {
				$all_post_link = get_site_url();
			}					
			
			?>
					
			<div class="vc_col-md-4 vc_col-sm-12 clearfix <?php echo esc_attr( $animation_class ); ?>" <?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
				<div class="entry <?php echo esc_attr( $post_style ); ?>">
					
					<?php 
					if ( has_post_thumbnail()) {
						$post_thumbnail= get_the_post_thumbnail( $post_id, array( 500, 300 ), array( 'class' => 'img-responsive' ) );														
					?>	
					<div class="entry-image">
						<a href="<?php echo esc_url( $link ); ?>">
							<?php echo $post_thumbnail; ?>						
						</a>
					</div>
					<?php } 					
					elseif ( $format == 'video' && $video_url ) { ?>
					<div class="entry-media embed-responsive embed-responsive-16by9">							
						<?php 
							echo wp_oembed_get( esc_url( $video_url ) );				
						?>
                    </div>
					<?php } 					
					elseif ( $format == 'audio' && $audio_url ) { ?>
					<div class="entry-media embed-responsive embed-responsive-16by9">
						<?php 
							echo wp_oembed_get( esc_url( $audio_url ) );				
						?>						
                    </div>
					<?php } ?>
					
					<div class="entry-wrap">
						<ul class="entry-meta clearfix">
							<li class="text-uppercase"><?php echo esc_html( $post_date ); ?></li>
							
							<?php if ( $show_label ) { ?>
								<li class="post-label <?php echo esc_attr( $format ); ?>"><?php echo esc_html( $format ); ?></li>
							<?php } ?>
						</ul>
						<span class="sep"></span>
						<div class="entry-title">
							<h3><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $post_title ); ?></a></h3>
						</div>
						
						<?php if ( $show_excerpt ) { ?>
						<div class="entry-content">
                            <?php echo esc_html( the_excerpt() ); ?>
                        </div>
						<?php } ?>
						
						<a href="<?php echo esc_url( $link ); ?>" class="more-link clearfix">
							<?php esc_html_e( 'READ MORE', 'engage' ); ?>
							<span class="pull-right">
								<i class="fa fa-angle-right"></i>
							</span>
						</a>
					</div>
				</div>
			</div>			
          
		<?php		
		}
		?>
		
		<?php if ( $show_all_post_btn )	{ ?>
			<div class="load-more-post align-center vc_col-sm-12 clearfix">
                    <a href="<?php echo esc_url( $all_post_link ); ?>" target="_blank" class="btn bordered-black slide-effect-theme">
						<?php esc_html_e( 'ALL POST', 'engage' ); ?>
					</a>
            </div>			
		<?php } ?>
			
		</div>	

		<?php
		}
		else { ?>
		
		<div><h1 class="err-msg"><?php esc_html_e( 'No Post Found, Please Add Post.', 'engage' ); ?></h1></div>
		<?php 
		
		}
		
		wp_reset_query();
		
		// Return outbut buffer
		return ob_get_clean();
		
	}
	
	function shortcode_vcmap() {
		
		$blog_cats = get_terms ( 'category', array( 'hide_empty' => false ) );
		$cats_array = array();
		foreach ( $blog_cats as $blog_cat ) {
			$cats_array[$blog_cat -> name] = $blog_cat -> slug;
		}

		vc_map( array(
			"name"					=> esc_html__( "Blog Grid", 'engage' ),
			"description"			=> esc_html__( "Recent blog posts grid", 'engage' ),
			"base"					=> "engage_blog_grid",
			"icon"					=> "engage-blog-grid-icon",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"params"				=> array(
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Post style", 'engage' ),
					"param_name"	=> "post_style",
					"value"         => array(
										esc_html__( 'Box with shadow', 'engage' )  => '',				
										esc_html__( 'Box with border', 'engage' )   => 'basic'                        
										),					
					"description"	=> esc_html__( 'Blog post style.', 'engage' ),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( "Select Categories", 'engage' ),
					"param_name"	=> "categories",
					"value"			=> $cats_array,
					"description"	=> esc_html__( 'Choose the category above, If you want to display posts from specific categories.', 'engage' )
				),
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Order Type", 'engage' ),
					"description"	=> esc_html__( "Designates the ascending or descending order", 'engage' ),
					"param_name"	=> "order",
					"value"			=> array(
										'Descending order from highest to lowest values (3, 2, 1; c, b, a)' => 'DESC',
										'Ascending order from lowest to highest values (1, 2, 3; a, b, c)' => 'ASC',
										),
					),
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Order By", 'engage' ),
					"description"	=> esc_html__( "Choose type of order", 'engage' ),
					"param_name"	=> "orderby",
					"value"			=> array(
										'Order by date of publication' => 'date',
										'Order by title' => 'title',
										'Order by author name' => 'author',
										'Order by post ID' => 'ID',
										'Random order' => 'rand',
										),
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Show Excerpt", 'engage' ),
					"param_name"	=> 'show_excerpt',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),					
					"description"	=> esc_html__("Show Excerpt.", 'engage'),					
				),		
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Show Label", 'engage' ),
					"param_name"	=> 'show_label',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),					
					"description"	=> esc_html__("Show post format labels.", 'engage'),					
				),		
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Show All Post Button", 'engage' ),
					"param_name"	=> 'show_all_post_btn',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),					
					"description"	=> esc_html__("Show All Post Button.", 'engage'),					
				),							
				array(
					"type"			=> "dropdown",
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					'value'			=> array(
											esc_html__( 'None', 'engage' ) => '',
											esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
											esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
											esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
											esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
											esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
											esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
											esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
											esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
											esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
											esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
											esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
											esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
											esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
											esc_html__( 'flipInX', 'engage' ) => 'flipInX',
											esc_html__( 'flipInY', 'engage' ) => 'flipInY',
											esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
											esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
											esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
											esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
											esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
											esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
											esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
											esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
											esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
											esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
											esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
											esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
											esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
											esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
											esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
											esc_html__( 'rollIn', 'engage' ) => 'rollIn',						
										),
					"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",
					"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",
					"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
			)
		) );
	}	
}

new Engage_Blog_Grid();