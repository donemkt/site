<?php
/**
 * Registers the animated icon box shortcode and adds it to the Visual Composer
 */

class Engage_Animated_Icon_Box {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_animated_icon_box', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {	
		
		extract( vc_map_get_attributes( 'engage_animated_icon_box', $atts ) );
		
		ob_start();				
		
		//idle title color
		$idle_title_color_style = '';
		if ( $idle_title_color ) {
			$idle_title_color_style = 'color:' . $idle_title_color . ';';
		}

		if ( $idle_title_color_style ) {
			$idle_title_color_style = ' style="' . esc_attr( $idle_title_color_style ) . '" ';
		}
		
		
		//hover title color
		$hover_title_color_style = '';
		if ( $hover_title_color ) {
			$hover_title_color_style = 'color:' . $hover_title_color . ';';
		}

		if ( $hover_title_color_style ) {
			$hover_title_color_style = ' style="' . esc_attr( $hover_title_color_style ) . '" ';
		}	
		
		
		//font color
		$font_color_style = '';
		if ( $font_color ) {
			$font_color_style = 'color:' . $font_color . ';';
		}

		if ( $font_color_style ) {
			$font_color_style = ' style="' . esc_attr( $font_color_style ) . '" ';
		}
		
		//icon color
		$icon_color_style = '';
		$theme_color_class = '';
		
		if ( $use_theme_color ) {
			
			$theme_color_class = 'theme-color';
		}
		else {
			
			if ( $icon_color ) {
				$icon_color_style = 'color:' . $icon_color . ';';
			}

			if ( $icon_color_style ) {
				$icon_color_style = ' style="' . esc_attr( $icon_color_style ) . '" ';
			}
		}
		
		//background color
		$bg_color_style = '';
		if ( $bg_color ) {
			$bg_color_style  = 'background-color:' . $bg_color . ';';		
		}
		
		if ( $use_border && $border_color ) {
			$bg_color_style  .= 'border-color:' . $border_color . ';';		
		}

		if ( $bg_color_style ) {
			$bg_color_style = ' style="' . esc_attr( $bg_color_style ) . '" ';
		}
		
		//border
		$border_class = '';
		if ( $use_border ) {			
			$border_class = 'bordered';
		}
		
		//hover color
		$hover_color_style = '';
		if ( $hover_color ) {
			$hover_color_style = 'background-color:' . $hover_color . ';';
		}

		if ( $hover_color_style ) {
			$hover_color_style = ' style="' . esc_attr( $hover_color_style ) . '" ';
		}
		
		//use animation
		$disable_animation_class = '';
		if ( $disable_animation ) {			
			$disable_animation_class = 'no-animation';
		}
		
		?>
		
		<div class="animated-icon-box <?php echo esc_attr( $disable_animation_class ); ?> <?php echo esc_attr( $border_class ); ?>" <?php echo $bg_color_style; ?>>
			<div class="aibox-outer">				
				<?php if ( $icon_type == 'fontawesome' ) { ?>
					<i class="<?php echo esc_attr( $icon_fontawesome ); ?> <?php echo esc_attr( $theme_color_class ); ?>" <?php echo $icon_color_style; ?>></i>
				<?php } else {
					?>
					<i class="<?php echo esc_attr( $icon_ionicons ); ?> <?php echo esc_attr( $theme_color_class ); ?>" <?php echo $icon_color_style; ?>></i>
					<?php }
				?>					
				<h5 <?php echo $idle_title_color_style; ?>><?php echo esc_html( $title ); ?></h5>
			</div>
			
			<?php if ( empty( $disable_animation ) ) { ?>
			<div class="aibox-inner-container" >
				<div class="aibox-inner-wrap" <?php echo $hover_color_style; ?>>
					<div class="aibox-inner-content">
						<?php if ( empty( $use_hover_title ) ) { ?>
							<h5 <?php echo $hover_title_color_style; ?>><?php echo esc_html( $title ); ?></h5>						
							<span class="aibox-title-sep"></span>
						<?php } ?>	
						<p <?php echo $font_color_style; ?>><?php echo esc_html( $desc ); ?></p>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
		
		<?php
		
		// Return outbut buffer
		return ob_get_clean();		
		

	}

	function shortcode_vcmap() {
			
		vc_map( array(
			"name"					=> esc_html__( "Animated Icon Box", 'engage' ),
			"description"			=> esc_html__( "A animated icon box.", 'engage' ),
			"base"					=> "engage_animated_icon_box",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"					=> "engage-animated-icon-box-icon",			
			"params"				=> array(				
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__("Title", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "title",
					"value"			=> "Web Design"
				),				
				array(
					"type"			=> "textarea",
					"heading"		=> esc_html__("Description", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "desc",					
				),
				array(
					"type"			=> "checkbox",					
					"heading"		=> esc_html__( "Disable Animation", 'engage' ),					
					"param_name"	=> "disable_animation",
					"value"         => array(
											esc_html__("Yes.", 'engage' )	=> 'yes',			
										),
					"description"	=> esc_html__( 'Check if you want to disable animation.', 'engage' ),
				),		
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Show Border", 'engage' ),
					"param_name"	=> 'use_border',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),					
					"description"	=> esc_html__("Check if you need border around the box.", 'engage')
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Border Color', 'engage' ),
					"param_name"	=> "border_color",						
					"value"			=> "rgba(0, 0, 0, 0.5)",						
				),				
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Hide title on hover", 'engage' ),
					"param_name"	=> 'use_hover_title',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"dependency"	=> array(
										'element'	=> 'use_animation',
										'is_empty'	=> true,
										),
					"description"	=> esc_html__("Check if you want to hide the title on hover animation.", 'engage')
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Title on idle', 'engage' ),
					"param_name"	=> "idle_title_color",	
					"value"			=> "#ffffff",
					"group"			=> esc_html__( 'Color', 'engage' ),
				),
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Title on hover', 'engage' ),
					"param_name"	=> "hover_title_color",	
					"value"			=> "#ffffff",
					"dependency"	=> array(
										'element'	=> 'use_hover_title',
										'is_empty'	=> true,
										),
					"group"			=> esc_html__( 'Color', 'engage' ),
				),
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Description', 'engage' ),
					"param_name"	=> "font_color",	
					"value"			=> "#ffffff",
					"group"			=> esc_html__( 'Color', 'engage' ),
				),
				
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Icon", 'engage' ),
					"param_name"	=> 'use_theme_color',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),										
					"group"			=> esc_html__( 'Color', 'engage' ),
					"description"	=> esc_html__( "Check it to Apply theme color to icon", 'engage' ),
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Icon', 'engage' ),
					"param_name"	=> "icon_color",		
					"dependency"	=> array(
										'element'	=> 'use_theme_color',
										'is_empty'	=> true,
										),
					"value"			=> "#ffffff",
					"group"			=> esc_html__( 'Color', 'engage' ),
				),
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Background on idle', 'engage' ),
					"param_name"	=> "bg_color",
					"value"			=> "rgba(255, 122, 113, 0.9)",
					"group"			=> esc_html__( 'Color', 'engage' ),
				),					
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Background on hover', 'engage' ),
					"param_name"	=> "hover_color",	
					"dependency"	=> array(
										'element'	=> 'use_animation',
										'is_empty'	=> true,
										),
					"value"			=> "rgba(0, 0, 0, 0.5)",						
					"group"			=> esc_html__( 'Color', 'engage' ),
				),							
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Icon library', 'engage' ),
					'value'			=> array(						
										esc_html__( 'Ion Icons', 'engage' ) => 'ionicons',
										esc_html__( 'Font Awesome', 'engage' ) => 'fontawesome',						
										),
					'param_name'	=> 'icon_type',
					'description'	=> esc_html__( 'Select icon library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_fontawesome',
					'value'			=> 'fa fa-bicycle',
					'settings'		=> array(
										'emptyIcon' => false,
										// default true, display an "EMPTY" icon?
										'iconsPerPage' => 4000,
										// default 100, how many icons per/page to display
									   ),
					'dependency'	=> array(
										'element' => 'icon_type',
										'value' => 'fontawesome',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_ionicons',
					'value'			=> 'ion-cube',
					'settings'		=> array(
										'emptyIcon' => false, // default true, display an "EMPTY" icon?
										'type'		=> 'ionicons',
										'source'	=> engage_iconpicker_type_ionicons(),
										),
					'dependency'	=> array(
										'element'	=> 'icon_type',
										'value'		=> 'ionicons',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),			
			)
		) );
	}
}

new Engage_Animated_Icon_Box();