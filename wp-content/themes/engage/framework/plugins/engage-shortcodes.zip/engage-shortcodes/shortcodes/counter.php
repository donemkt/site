<?php
/**
 * Registers the icon box shortcode and adds it to the Visual Composer
 */

class Engage_Counter {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_counter', array( $this, 'shortcode' ) );
		
	}	
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_counter', $atts ) );
		
		ob_start();	
		
		$data_attr  = '';
		$data_attr .= ( $count_from ) ? ' data-from	= '. intval( $count_from )			  : ' data-from = 0';		
		$data_attr .= ( $count_to )   ? ' data-to = '. intval( $count_to )				  : ' data-to = 100';		
		$data_attr .= ( $speed )	  ? ' data-speed = '. intval( $speed )				  : ' data-speed = 2500';		
		$data_attr .= ( $interval )   ? ' data-refresh-interval = '. intval( $interval )  : ' data-refresh-interval = 50';		
		
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		//Title Color
		$number_style = '';
		$number_theme_color_class = '';
		
		if ( $number_use_theme_color ) {
			$number_theme_color_class = 'theme-color';			
		}
		elseif ( $number_color ) {	
			$number_style = 'color:'. $number_color .';';
		}	

		if ( $number_style ) {
			$number_style = ' style="' . esc_attr( $number_style ) . '"';
		}
		
		//Icon Color
		$icon_style = '';
		$icon_theme_color_class = '';		
		
		if ( $icon_use_theme_color ) {
			$icon_theme_color_class = 'theme-color';					
		}
		elseif ( $icon_color ) {	
			$icon_style = 'color:'. $icon_color .';';
		}	

		if ( $icon_style ) {
			$icon_style = ' style="' . esc_attr( $icon_style ) . '"';
		}
			
		
		?>		
		
        <div class="counter <?php echo esc_attr( $counter_type ); ?> <?php echo esc_attr( $animation_class ); ?>" 
			<?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?> >
			
			<?php if ( $counter_type == 'counter-outlined' ) { ?>
				<span class="counter-title"><?php echo esc_html( $upper_title ); ?></span>
				<div class="counter-outline">
                    <div class="sep" style="background-color:<?php echo esc_attr( $separator_color ); ?>"></div>
			<?php }
			else {
			?>
				<?php if ( $icon_type == 'fontawesome' ) { ?>
					<i class="counter-icon <?php echo esc_attr( $icon_fontawesome ); ?> <?php echo esc_attr( $icon_theme_color_class ); ?>" <?php echo $icon_style; ?>></i>
				<?php } else {
					?>
					<i class="counter-icon <?php echo esc_attr( $icon_ionicons ); ?> <?php echo esc_attr( $icon_theme_color_class ); ?>" <?php echo $icon_style; ?>></i>
					<?php }
				?>					
				
			<?php			
			}
			?>
					
            
            <div class="counter-value <?php echo esc_attr( $number_theme_color_class ); ?>" <?php echo $number_style; ?> <?php echo $data_attr; ?>><?php echo intval( $count_to ); ?></div>
            <p class="counter-desc"><?php echo esc_html( $caption ); ?></p>
			
			<?php if ( $counter_type == 'counter-outlined' ) { ?>
				</div>
			<?php } ?>
        </div>
        		
		<?php
		
		// Return outbut buffer
		return ob_get_clean();		
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Animated Counter", 'engage' ),
			"description"			=> esc_html__( "Animated counter", 'engage' ),
			"base"					=> "engage_counter",
			"icon" 					=> "engage-counter-icon",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"params"				=> array(
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Counter Style", 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "counter_type",
					"value"         => array(
										esc_html__( "Icon", 'engage' )			=> "",
										esc_html__( "Outlined", 'engage' )		=> "counter-outlined"						
										),
					"description"	=> esc_html__( 'Choose Counter style.', 'engage' ),
				),
				array(
					"type"			=> "textfield",
					"admin_label"	=> true,				
					"heading"		=> esc_html__( "Count Numbers From", 'engage' ),
					"param_name"	=> "count_from",
					"value"			=> "0",					
				),
				array(
					"type"			=> "textfield",
					"admin_label"	=> true,				
					"heading"		=> esc_html__( "Count Numbers To", 'engage' ),
					"param_name"	=> "count_to",
					"value"			=> "45",					
				),				
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Upper Title", 'engage' ),									
					"param_name"	=> "upper_title",
					"dependency"	=> array(
										'element'	=> 'counter_type',
										'value'		=> 'counter-outlined',
										),
					"description"	=> esc_html__('Enter Title for counter type box.','engage'),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Caption", 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "caption",				
					"description"	=> esc_html__('Your caption displays below the numbers.','engage'),
					"value"			=> "Projects Done",
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Numbers", 'engage' ),
					"param_name"	=> 'number_use_theme_color',
					"description"	=> esc_html__('Check it to Apply theme color to Numbers.','engage'),
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),										
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Numbers', 'engage' ),
					"param_name"	=> "number_color",
					"description"	=> esc_html__('Choose Color for Numbers.','engage'),
					"dependency"	=> array(
										'element'	=> 'number_use_theme_color',
										'is_empty'	=> true,
										),		
					"value"			=> "#ffffff",
				),
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Separator Background Color', 'engage' ),
					"param_name"	=> "separator_color",		
					"dependency"	=> array(
										'element'	=> 'counter_type',
										'value'		=> 'counter-outlined',
										),
					"value"			=> "#f1f1f1",
					"description"	=> esc_html__("Seperator background color should be same as row background color.", 'engage'),					
				),	
				array(
					"type"			=> "textfield",				
					"heading"		=> esc_html__( "Speed", 'engage' ),
					"param_name"	=> "speed",
					"value"			=> "2500",
					"description"	=> esc_html__('The number of milliseconds it should take to finish counting.','engage'),
				),
				array(
					"type"			=> "textfield",
					"heading"		=> esc_html__( "Refresh Interval", 'engage' ),
					"param_name"	=> "interval",
					"value"			=> "50",
					"description"	=> esc_html__('The number of milliseconds to wait between refreshing the counter.','engage'),
				),					
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Icon", 'engage' ),
					"param_name"	=> 'icon_use_theme_color',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),	
					"dependency"	=> array(
										'element'	=> 'counter_type',
										'is_empty'	=> true,
										),
					"description"	=> esc_html__("Check it to Apply theme color to Icon", 'engage'),
					"group"			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Icon', 'engage' ),
					"param_name"	=> "icon_color",		
					"dependency"	=> array(
										'element'	=> 'icon_use_theme_color',
										'is_empty'	=> true,
										),
					"value"			=> "#ffffff",
					"description"	=> esc_html__("Choose Color for Icon", 'engage'),
					"group"			=> esc_html__( 'Icon', 'engage' ),
				),			
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Icon library', 'engage' ),
					'value'			=> array(						
										esc_html__( 'Ion Icons', 'engage' ) => 'ionicons',
										esc_html__( 'Font Awesome', 'engage' ) => 'fontawesome',						
										),
					'param_name'	=> 'icon_type',
					"dependency"	=> array(
										'element'	=> 'counter_type',
										'is_empty'	=> true,
										),
					'description'	=> esc_html__( 'Select icon library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_fontawesome',
					'value'			=> 'fa fa-bicycle',
					'settings'		=> array(
										'emptyIcon' => false,
										// default true, display an "EMPTY" icon?
										'iconsPerPage' => 4000,
										// default 100, how many icons per/page to display
									   ),
					'dependency'	=> array(
										'element' => 'icon_type',
										'value' => 'fontawesome',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_ionicons',
					'value'			=> 'ion-cube',
					'settings'		=> array(
										'emptyIcon' => false, // default true, display an "EMPTY" icon?
										'type'		=> 'ionicons',
										'source'	=> engage_iconpicker_type_ionicons(),
										),
					'dependency'	=> array(
										'element'	=> 'icon_type',
										'value'		=> 'ionicons',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"         => array(
										esc_html__( 'None', 'engage' )      => '',                      
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',	                                          
									   ),
					"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__('Animation Delay Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__('Animation Duration Timming.','engage'),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Counter();