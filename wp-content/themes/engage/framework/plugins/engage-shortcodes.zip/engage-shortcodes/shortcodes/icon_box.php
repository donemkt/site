<?php
/**
 * Registers the icon box shortcode and adds it to the Visual Composer
 */

class Engage_Icon_Box {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_icon_box', array( $this, 'shortcode' ) );
		
	}	
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_icon_box', $atts ) );
		
		ob_start();	
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
			$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
		}
		
		$iconbox_class = '';
		$icon_class    = '';
		
		if ( $iconbox_type == 'type2') {			
			$iconbox_class = 'ibox-left';			
		}		
		elseif ( $iconbox_type == 'type3') {			
			$iconbox_class = 'ibox-small ibox-small-left icon-only';			
		}
		elseif ( $iconbox_type == 'type4') {			
			$iconbox_class = 'ibox-small icon-only';			
		}
		elseif ( $iconbox_type == 'type5') {			
			$iconbox_class = 'ibox-small ibox-small-right icon-only';			
		}
		elseif ( $iconbox_type == 'type6') {			
			$iconbox_class = 'ibox-small ibox-small-left';
			$icon_class = 'ibox-icon-bordered';			
		}
		elseif ( $iconbox_type == 'type7') {			
			$iconbox_class = 'ibox-small';
			$icon_class = 'ibox-icon-bordered';			
		}
		elseif ( $iconbox_type == 'type8') {			
			$iconbox_class = 'ibox-small ibox-small-right';
			$icon_class = 'ibox-icon-bordered';			
		}		
		elseif ( $iconbox_type == 'type9') {			
			$iconbox_class = 'ibox-small ibox-small-left';
			$icon_class = 'ibox-icon-round';			
		}
		elseif ( $iconbox_type == 'type10') {			
			$iconbox_class = 'ibox-small';
			$icon_class = 'ibox-icon-round';			
		}
		elseif ( $iconbox_type == 'type11') {			
			$iconbox_class = 'ibox-small ibox-small-right';
			$icon_class = 'ibox-icon-round';			
		}
		elseif ( $iconbox_type == 'type12') {			
			$iconbox_class = 'ibox-small ibox-small-left ibox-small-bordered';			
		}
		elseif ( $iconbox_type == 'type13') {			
			$iconbox_class = 'ibox-small ibox-small-left ibox-small-bordered';
			$icon_class = 'ibox-small-icon-offset';
		}
		elseif ( $iconbox_type == 'type14') {			
			$iconbox_class = 'ibox-small ibox-small-left-slant';
			$icon_class = 'ibox-icon-slant-box-left';
		}
		elseif ( $iconbox_type == 'type15') {			
			$iconbox_class = 'ibox-small ibox-small-left-slant';
			$icon_class = 'ibox-icon-slant-box-right';
		}
		elseif ( $iconbox_type == 'type16') {			
			$iconbox_class = 'ibox-small ibox-small-right-slant';
			$icon_class = 'ibox-icon-slant-box-left';
		}
		elseif ( $iconbox_type == 'type17') {			
			$iconbox_class = 'ibox-small ibox-small-right-slant';
			$icon_class = 'ibox-icon-slant-box-right';
		}
		elseif ( $iconbox_type == 'type18') {			
			$iconbox_class = 'ibox-small';
			$icon_class = 'ibox-icon-slant-box-left';
		}
		elseif ( $iconbox_type == 'type19') {			
			$iconbox_class = 'ibox-small';
			$icon_class = 'ibox-icon-slant-box-right';
		}
		
		//Title Color
		$title_style = '';
		$title_theme_color_class = '';
		
		if ( $title_use_theme_color ) {
			$title_theme_color_class = 'class = "theme-color"';			
		}
		elseif ( $title_color ) {	
			$title_style = 'color:'. $title_color .';';
		}	

		if ( $title_style ) {
			$title_style = ' style="' . esc_attr( $title_style ) . '"';
		}
		
		//icon color
		$icon_color_style = '';
		$icon_bg_color_style = '';
		$theme_color_class = '';
		$theme_bg_color_class = '';
		
		
		if ( $use_theme_color ) {
			
			$theme_color_class = 'theme-color';
			
			if ( $iconbox_type == 'type9' || $iconbox_type == 'type10' || $iconbox_type == 'type11') {			
				$theme_color_class = ' theme-bg-color';
			}
			elseif ( $iconbox_type == 'type12' || $iconbox_type == 'type13') {			
				$theme_color_class = '';
				$theme_bg_color_class = 'theme-bg-color';
			}
		}
		else {
			
			if ( $icon_color ) {			
				
				if ( $iconbox_type == 'type12' || $iconbox_type == 'type13') {
					$icon_bg_color_style = 'background-color:' . $icon_color . ';';
				}
				else {
					$icon_color_style = 'color:' . $icon_color . ';';
				}
			}
			
			if ( $iconbox_type == 'type9' || $iconbox_type == 'type10' || $iconbox_type == 'type11') {			
				$icon_color_style = 'background-color:' . $icon_color . ';';
			}		
			

			if ( $icon_color_style ) {				
				$icon_color_style = ' style="' . esc_attr( $icon_color_style ) . '" ';
			}
			
			if ( $icon_bg_color_style ) {				
				$icon_bg_color_style = ' style="' . esc_attr( $icon_bg_color_style ) . '" ';
			}
		}
		
		//text color
		$text_style = '';
		if ($text_color) {	
			$text_style = 'color:'. $text_color .';';
		}

		if ( $text_style ) {
			$text_style = ' style="' . esc_attr( $text_style ) . '"';
		}		
		
		?>

		<div class="icon-box <?php echo esc_attr( $iconbox_class ); ?> <?php echo esc_attr( $animation_class ); ?>" 
					<?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
			<div class="ibox-icon <?php echo esc_attr( $icon_class ); ?> <?php echo esc_attr( $theme_bg_color_class ); ?>" <?php echo $icon_bg_color_style; ?>>
				<?php if ( $icon_type == 'fontawesome' ) { ?>
					<i class="<?php echo esc_attr( $icon_fontawesome ); ?> <?php echo esc_attr( $theme_color_class ); ?>" <?php echo $icon_color_style; ?>></i>
				<?php } else {
					?>
					<i class="<?php echo esc_attr( $icon_ionicons ); ?> <?php echo esc_attr( $theme_color_class ); ?>" <?php echo $icon_color_style; ?>></i>
					<?php }
				?>					
			</div>
			<h3 <?php echo esc_attr( $title_theme_color_class ); ?> <?php echo $title_style; ?>><?php echo esc_html( $title ); ?></h3>

			<?php if ( $use_separator ) { ?>
				<span class="ibox-title-sep"></span>
			<?php } ?>

			<p <?php echo $text_style; ?>><?php echo esc_html( $desc ); ?></p>
		</div>

		<?php
		
		// Return outbut buffer
		return ob_get_clean();		
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Icon Box", 'engage' ),
			"description"			=> esc_html__( "A icon content box.", 'engage' ),
			"base"					=> "engage_icon_box",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),
			"icon"					=> "engage-icon-box-icon",
			"params"				=> array(
				array(
					"type"			=> "dropdown",
					"admin_label"	=> true,
					"heading"		=> esc_html__( 'Icon Box Style', 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "iconbox_type",
					"value"         => array(
											esc_html__( "Boxed Top Icon", 'engage' )				=> "type1",
											esc_html__( "Boxed Left Icon", 'engage' )			=> "type2",
											esc_html__( "Left Icon", 'engage' )					=> "type3",										
											esc_html__( "Top Icon", 'engage' )					=> "type4",										
											esc_html__( "Right Icon", 'engage' )					=> "type5",										
											esc_html__( "Left Bordered Icon", 'engage' )			=> "type6",
											esc_html__( "Center Bordered Icon", 'engage' )		=> "type7",
											esc_html__( "Right Bordered Icon", 'engage' )		=> "type8",
											esc_html__( "Left Rounded Icon", 'engage' )			=> "type9",
											esc_html__( "Center Rounded Icon", 'engage' )		=> "type10",
											esc_html__( "Right Rounded Icon", 'engage' )			=> "type11",
											esc_html__( "Dual Boxed Left Icon", 'engage' )			=> "type12",
											esc_html__( "Dual Boxed Offset Left Icon", 'engage' )	=> "type13",
											esc_html__( "Left Icon Slant Left", 'engage' )		    => "type14",
											esc_html__( "Left Icon Slant Right", 'engage' )		    => "type15",
											esc_html__( "Right Icon Slant Left", 'engage' )		    => "type16",
											esc_html__( "Right Icon Slant Right", 'engage' )		=> "type17",
											esc_html__( "Center Icon Slant Left", 'engage' )		=> "type18",
											esc_html__( "Center Icon Slant Right", 'engage' )		=> "type19",
									    ),
				),				
				array(
					"type"			=> "textfield",
					"admin_label"	=> true,
					"heading"		=> esc_html__( 'Title', 'engage' ),
					"param_name"	=> "title",
					"value"			=> "Unique Design",					
					"description"	=> esc_html__("Enter Title.", 'engage')
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Title", 'engage' ),
					"param_name"	=> 'title_use_theme_color',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes'
										),					
					"description"	=> esc_html__("Check it to Apply theme color to title .", 'engage'),
																		
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Title', 'engage' ),
					"param_name"	=> "title_color",
					"dependency"	=> array(
										'element'	=> 'title_use_theme_color',
										'is_empty'	=> true,
										),					
					"description"	=> esc_html__("Choose Color for title .", 'engage')
				),				
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Separator", 'engage' ),
					"param_name"	=> 'use_separator',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"dependency"	=> array(
										'element'	=> 'iconbox_type',
										'value'		=> array ( 'type12', 'type13' )
										),
					"description"	=> esc_html__("Use separator between Title and Description.", 'engage')
				),
				array(
					"type"			=> "textarea",					
					"heading"		=> esc_html__( "Description", 'engage' ),
					"admin_label"	=> true,
					"param_name"	=> "desc",
					"value"			=> esc_html__( 'Don\'t forget to change this dummy text.', 'engage' )
				),			
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Description Custom Color', 'engage' ),
					"param_name"	=> "text_color",					
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Theme Color for Icon", 'engage' ),
					"param_name"	=> 'use_theme_color',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),					
					"description"	=> esc_html__("Check it to Apply theme color to icon.", 'engage'),
					"group"			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					"type"			=> "colorpicker",
					"heading"		=> esc_html__( 'Use Custom Color for Icon', 'engage' ),
					"param_name"	=> "icon_color",		
					"dependency"	=> array(
										'element'	=> 'use_theme_color',
										'is_empty'	=> true,
										),
					"value"			=> "#202020",
					"description"	=> esc_html__("Choose Color for icon.", 'engage'),
					"group"			=> esc_html__( 'Icon', 'engage' ),
				),			
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Icon library', 'engage' ),
					'value'			=> array(						
										esc_html__( 'Ion Icons', 'engage' ) => 'ionicons',
										esc_html__( 'Font Awesome', 'engage' ) => 'fontawesome',						
										),
					'param_name'	=> 'icon_type',
					'description'	=> esc_html__( 'Select icon library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_fontawesome',
					'value'			=> 'fa fa-bicycle',
					'settings'		=> array(
										'emptyIcon' => false,
										// default true, display an "EMPTY" icon?
										'iconsPerPage' => 4000,
										// default 100, how many icons per/page to display
									   ),
					'dependency'	=> array(
										'element' => 'icon_type',
										'value' => 'fontawesome',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),				
				array(
					'type'			=> 'iconpicker',
					'heading'		=> esc_html__( 'Icon', 'engage' ),
					'param_name'	=> 'icon_ionicons',
					'value'			=> 'ion-cube',
					'settings'		=> array(
										'emptyIcon' => false, // default true, display an "EMPTY" icon?
										'type'		=> 'ionicons',
										'source'	=> engage_iconpicker_type_ionicons(),
										),
					'dependency'	=> array(
										'element'	=> 'icon_type',
										'value'		=> 'ionicons',
										),
					'description'	=> esc_html__( 'Select icon from library.', 'engage' ),
					'group'			=> esc_html__( 'Icon', 'engage' ),
				),
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					'value'         => array(
										esc_html__( 'None', 'engage' )      => '',                      
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',	                   
									  ),
					"description"	=> esc_html__( 'Animation Effect for feature box.', 'engage' ),
					'group'			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Icon_Box();