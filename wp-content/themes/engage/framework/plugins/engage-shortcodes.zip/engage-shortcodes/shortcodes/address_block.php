<?php
/**
 * Registers the adddress block shortcode and adds it to the Visual Composer
 */

class Engage_Address_Block {
	
	public function __construct() {
		
		add_action( 'vc_before_init', array( $this, 'shortcode_vcmap' ) );
		
		add_shortcode( 'engage_address_block', array( $this, 'shortcode' ) );
		
	}
	
	function shortcode( $atts, $content = null ) {
		
		extract( vc_map_get_attributes( 'engage_address_block', $atts ) );
		
		ob_start();	
		
		$has_icon_class = '';
		if ( $use_icon ) {
			$has_icon_class = 'has-icon';		
		}
		
		$has_icon_bg_class = '';
		if( $use_icon_bg ) {
			$has_icon_bg_class = 'has-icon-bg';
		}
		
		$light_text_class= '';		
		if ( $light_text ) {
			$light_text_class = 'light';
		}
		
		//animation
		$animation_class = '';
		$animation_delay_attr = '';
		$animation_duration_attr = '';
		
		if( $animation_effect != '' ) {
			$animation_class = 'wow '.$animation_effect;		
			$animation_delay_attr = 'data-wow-delay="'. esc_attr( $animation_delay ) .'s"';
			$animation_duration_attr = 'data-wow-duration="'. esc_attr( $animation_duration ) .'s"';
		}		
			
		?>
		
			<div class="contact-info-wrap <?php echo esc_attr( $address_style ); ?> <?php echo esc_attr( $has_icon_class ); ?> 
				<?php echo esc_attr( $has_icon_bg_class ); ?> <?php echo esc_attr( $align_icon ); ?> 
									     <?php echo esc_attr( $animation_class ); ?> <?php echo esc_attr( $light_text_class ); ?>" 
										 <?php echo $animation_delay_attr; ?> <?php echo $animation_duration_attr; ?>>
			
			<?php if ( $address_style == 'grid-style' ) { ?>
			<div class="vc_col-sm-4">
			<?php } ?>
				
				<div class="contact-info-item">
					
					<?php if ( $address_style == '' && $address_title ) { ?>
					<div><strong><?php echo esc_html( $address_title ); ?> :</strong> </div>
					<?php } ?>
					
					<?php if ( $use_icon ) { ?>
					<div><i class="ion-home"></i></div>
					<?php } ?>					
					
					<div class="contact-desc">
						<?php if ( $address_style == 'grid-style' ) { ?>
						<strong><?php echo esc_html( $address_title ); ?></strong><br/>
						<?php } ?>
						<?php echo wp_kses( $address, array( 'br' => array() ) ); ?>
					</div>
				</div>
			
			<?php if ( $address_style == 'grid-style' ) { ?>
			</div>
			<?php } ?>
			
			<?php if ( $address_style == 'grid-style' ) { ?>
			<div class="vc_col-sm-4">
			<?php } ?>
					
			<div class="contact-info-item">
				
				<?php if ( $address_style == '' && $phone_title ) { ?>
				<div class="contact-desc"><strong><?php echo esc_html( $phone_title ); ?> :</strong></div>
				<?php } ?>
				
				<?php if ( $use_icon ) { ?>
				<div><i class="ion-iphone"></i></div>
				<?php } ?>
				
				<div class="contact-desc">
					<?php if ( $address_style == 'grid-style' ) { ?>
					<strong><?php echo esc_html( $phone_title ); ?></strong><br/>
					<?php } ?>
					<span class="number"><?php echo esc_html( $phone ); ?></span>
				</div>
				
			</div>
			
			<?php if ( $address_style == 'grid-style' ) { ?>
			</div>
			<?php } ?>
			
			<?php if ( $address_style == 'grid-style' ) { ?>
			<div class="vc_col-sm-4">
			<?php } ?>
			
			<div class="contact-info-item">
				
				<?php if ( $address_style == '' && $email_title ) { ?>
				<div class="contact-desc"><strong><?php echo esc_html( $email_title ); ?> :</strong></div>
				<?php } ?>
				
				<?php if ( $use_icon ) { ?>
				<div><i class="ion-ios-email-outline"></i></div>
				<?php } ?>			
				
				<div class="contact-desc">
					<?php if ( $address_style == 'grid-style' ) { ?>
					<strong><?php echo esc_html( $email_title ); ?></strong><br/>
					<?php } ?>
					<?php if ( is_email( sanitize_email( $email ) ) ) { ?>
					<a href="mailto:<?php echo sanitize_email( $email ); ?>"><?php echo sanitize_email( $email ); ?></a>
					<?php } ?>
				</div>
				
			</div>
			
			<?php if ( $address_style == 'grid-style' ) { ?>
			</div>
			<?php } ?>

		</div>
		

		<?php
		
		// Return outbut buffer
		return ob_get_clean();	
		
	}

	function shortcode_vcmap() {
		
		vc_map( array(
			"name"					=> esc_html__( "Address Block", 'engage' ),
			"description"			=> esc_html__( "Show off your contact data", 'engage' ),
			"base"					=> "engage_address_block",
			"icon" 					=> "engage-address-block-icon",
			"category"				=> ucfirst( ENGAGE_THEME_NAME ),			
			"params"				=> array(
				array(
					"type"			=> "dropdown",				
					"heading"		=> esc_html__("Address Block Style", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "address_style",
					"value"			=> array(					
										esc_html__( 'List', 'engage' )	=>	'',
										esc_html__( 'Grid','engage' )    =>	'grid-style',
										),
					"description"	=> esc_html__("Specify address block style.", 'engage'),
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Show icon", 'engage' ),
					"param_name"	=> 'use_icon',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"description"	=> esc_html__("Show icon on heading.", 'engage')
				),
				array(
					"type"			=> 'checkbox',
					"heading"		=> esc_html__( "Use Icon Background", 'engage' ),
					"param_name"	=> 'use_icon_bg',
					"value"			=> array(
											esc_html__("Yes.", 'engage' )	=> 'yes',
										),
					"dependency"	=> array(
										'element'	=> 'address_style',
										'is_empty'	=> true,
									   ),
					"description"	=> esc_html__("Show background in icon.", 'engage')
				),
				array(
					"type"			=> "dropdown",				
					"heading"		=> esc_html__("Align Icon", 'engage'),					
					"param_name"	=> "align_icon",
					"value"			=> array(					
										esc_html__( 'Left', 'engage' )	=>	'',
										esc_html__( 'Center','engage' ) =>	'center-aligned',
										),
					"dependency"	=> array(
										'element'	=> 'address_style',
										'value'		=> 'grid-style',
									   ),
					"description"	=> esc_html__("Alignment of Icons.", 'engage'),
				),
				array(
					"type"			=> "checkbox",
					"heading"		=> esc_html__( 'Use Light Text', 'engage' ),
					"param_name"	=> "light_text",
					"value"			=> array(
										esc_html__( 'Yes', 'engage' )	=> 'yes',
										),	
					"dependency"	=> array(
										'element'	=> 'address_style',
										'value'		=> 'grid-style',
									   ),
					"description"	=> esc_html__( "Check for light text.", 'engage' ),										
				),	
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Address Title", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "address_title",					
					"value"			=> "",	
					"group"			=> esc_html__( 'Address Details', 'engage' ),
				),
				array(
					"type"			=> "textarea",					
					"heading"		=> esc_html__("Address", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "address",
					"value"			=> "",	
					"group"			=> esc_html__( 'Address Details', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Phone Number title", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "phone_title",
					"value"			=> "",
					"group"			=> esc_html__( 'Address Details', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Phone Number", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "phone",
					"value"			=> "",
					"group"			=> esc_html__( 'Address Details', 'engage' ),
				),				
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("Email title", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "email_title",
					"value"			=>  "",
					"group"			=> esc_html__( 'Address Details', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__("E-mail", 'engage'),
					"admin_label"	=> true,
					"param_name"	=> "email",
					"value"			=>  "",
					"group"			=> esc_html__( 'Address Details', 'engage' ),
				),				
				array(
					"type"			=> "dropdown",					
					"heading"		=> esc_html__( "Animation Effect", 'engage' ),
					"param_name"	=> "animation_effect",
					"value"         => array(
										esc_html__( 'None', 'engage' ) => '',
										esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
										esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
										esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
										esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
										esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
										esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
										esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
										esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
										esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
										esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
										esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
										esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
										esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
										esc_html__( 'flipInX', 'engage' ) => 'flipInX',
										esc_html__( 'flipInY', 'engage' ) => 'flipInY',
										esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
										esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
										esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
										esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
										esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
										esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
										esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
										esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
										esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
										esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
										esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
										esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
										esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
										esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
										esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
										esc_html__( 'rollIn', 'engage' ) => 'rollIn',						                    
									),
					"description"	=> esc_html__( 'Animation Effect for Address block.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Delay", 'engage' ),
					"param_name"	=> "animation_delay",
					"value"			=> "0.5",					
					"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
				array(
					"type"			=> "textfield",					
					"heading"		=> esc_html__( "Animation Duration", 'engage' ),
					"param_name"	=> "animation_duration",
					"value"			=> "1",					
					"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
					"group"			=> esc_html__( 'Animation', 'engage' ),
				),		
			)
		) );
	}
}

new Engage_Address_Block();