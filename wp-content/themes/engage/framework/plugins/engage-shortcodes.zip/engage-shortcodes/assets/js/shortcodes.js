(function($) {
    'use strict';

    // VARS           
    var portfolioGrid = $( '#portfolio-grid-container' );       

    /*----------------------------------------------------*/
    /* MOBILE DETECT FUNCTIONS
    /*----------------------------------------------------*/

    var isMobile = {
        Android: function() {
            return navigator.userAgent.match( /Android/i );
        },
        BlackBerry: function() {
            return navigator.userAgent.match( /BlackBerry/i );
        },
        iOS: function() {
            return navigator.userAgent.match( /iPhone|iPad|iPod/i );
        },
        Opera: function() {
            return navigator.userAgent.match( /Opera Mini/i );
        },
        Windows: function() {
            return navigator.userAgent.match( /IEMobile/i );
        },
        any: function() {
            return ( isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows() );
        }

    };        

    /* --------------------------------*/
    /* - Doc Ready
     /* -------------------------------*/

    $( document ).ready( function() {      

        /*----------------------------------------------------*/
        /* Initialize Animation
        /*----------------------------------------------------*/

        if ( !isMobile.any() && engageShortcodeJs.animationSwitch == 1 ) {           
           initializeAnimation();            
        }            

        /*----------------------------------------------------*/
        /* Disable Parallax on mobile
        /*----------------------------------------------------*/
        
        if ( isMobile.any() && typeof (skrollr) !== 'undefined' ) {           
            skrollr.init().destroy();
        }

        /*----------------------------------------------------*/
        /*  Progress Bar
        /*----------------------------------------------------*/
        
        $( '.skill-bar li' ).each( function() {            

            $( this ).appear( function() {
                $( this ).css({ opacity: 1, left: "0px" });
                var b = $( this ).find( ".progress-bar" ).attr( "data-width" );
                $( this ).find( ".progress-bar" ).css({
                    width: b + "%"
                });
            });           

        });     

        /*----------------------------------------------------*/
        /*  Counter
         /*----------------------------------------------------*/       

        $(".counter").appear(function() {
            $('.counter-value').each(function() {            
                $(this).delay(3000).countTo();
            });
        });            



        /*----------------------------------------------------*/
        /*  Slider
         /*----------------------------------------------------*/       
        
        // Carousels
        $( '.golo-carousel' ).each( function() {
            var carousel = $( this );
            carousel.owlCarousel({ 
                autoplay            : ( isMobile.any() || carousel.data( "autoplay" ) == null)      ? false : carousel.data( "autoplay" ),
                autoplaySpeed       : ( isMobile.any() || carousel.data( "autoplayspeed" ) == null) ? false : carousel.data( "autoplayspeed" ),
                loop                : ( carousel.data( "loop" ) == null )        ? true  : carousel.data( "loop" ),
                items               : ( carousel.data( "items" ) == null )       ? 1     : carousel.data( "items" ),             
                autoplayHoverPause  : ( carousel.data( "stoponhover" ) == null ) ? false : carousel.data( "stoponhover" ),
                slideBy             : ( carousel.data( "slideby" ) == null )     ? 1     : carousel.data( "slideby" ),
                nav                 : ( carousel.data( "nav") == null )          ? false : carousel.data( "nav" ),
                navText             : [ '<span class="ion-ios-arrow-left"></span>', '<span class="ion-ios-arrow-right"></span>' ],
                navSpeed            : ( carousel.data( "navspeed") == null )     ? false : carousel.data( "navspeed" ),
                dots                : ( carousel.data( "dots") == null )         ? false : carousel.data( "dots" ),
                dotsSpeed           : ( carousel.data( "dotsspeed") == null )    ? false : carousel.data( "dotsspeed" ),
                animateOut          : ( carousel.data( "animateout") == null )   ? false : carousel.data( "animateout" ),
                animateIn           : ( carousel.data( "animatein") == null )    ? false : carousel.data( "animatein" ),
                responsive: {
                    0: {
                        items: ( carousel.data( "items-mobile-portrait" ) == null)  ? 1 : carousel.data( "items-mobile-portrait" )
                    },
                    480: {
                        items: ( carousel.data( "items-mobile-landscape" ) == null) ? 1 : carousel.data( "items-mobile-landscape" )
                    },
                    768: {
                        items: ( carousel.data( "items-tablet" ) == null)           ? 1 : carousel.data( "items-tablet" )
                    },
                    960: {
                        items: ( carousel.data( "items" ) == null)                  ? 1 : carousel.data( "items" )
                    }
                }
            });  
        });

        

        /*----------------------------------------------------*/
        /*  Columns equal heights
        /*----------------------------------------------------*/                      

        $( '.gt_equal_heights' ).each( function() {      

            if ( $( this ).find( '.wpb_column.vc_column_container .wpb_wrapper .featured-img-box' ).exists() ) {                
              $( this ).find( '.wpb_column.vc_column_container .wpb_wrapper .featured-img-box' ).matchHeight();             
            }            
            else {
                $( this ).find( '.wpb_column.vc_column_container' ).matchHeight();            
                $( this ).find( '.wpb_column.vc_column_container .wpb_wrapper .icon-box' ).matchHeight();           
            }
        });
        

        /*----------------------------------------------------*/
        /*  Apply image background on video for mobile
        /*----------------------------------------------------*/              
        
        $( '.vc_video-bg-container' ).each( function() {         
            if ( $( this ).attr( 'data-mobile-bg-image' ) ) {
                $( this ).css( 'background-image', 'url(' + $( this ).data( "mobile-bg-image" ) + ') ' );
            }
        });       
        

        /*----------------------------------------------------*/
        /* MAGNIFIC POPUP LOAD CONTENT VIA AJAX INLINE
        /*----------------------------------------------------*/
        $( '.html-popup' ).magnificPopup({ type: 'inline' });    
       
        
        /*----------------------------------------------------*/
        /* MAGNIFIC POPUP LOAD VIDEO FROM VIDEO MODAL 
        /*----------------------------------------------------*/
        $('.modal-popup-video').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false,
            closeMarkup:'<div class="mfp-close video-modal-close ion-ios-close-empty"></div>',
            iframe: {
                      markup: '<div class="mfp-iframe-scaler video-modal-popup">'+
                                '<div class="mfp-close test"></div>'+
                                '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
                              '</div>'
                    }
        });

          
        //CUSTOM TOOLBAR
        $( ".member-skills" ).mCustomScrollbar({
            theme: "dark-3",
            live: "on",
        });

        /*----------------------------------------------------*/
        /* VIDEO IN BACKGROUND
        /*----------------------------------------------------*/
        
        $( '.vc_video-bg-container' ).each( function () {

		var $row = jQuery( this ), youtubeUrl, youtubeId;
                
		if ( $row.data( 'vcVideoBg' ) ) {
			youtubeUrl = $row.data( 'vcVideoBg' );
			youtubeId = vcExtractYoutubeId( youtubeUrl );
                        
			if ( youtubeId ) {
				$row.find( '.vc_video-bg' ).remove();
				insertYoutubeVideoAsBackground( $row, youtubeId );
			}
                        
			jQuery( window ).on( 'grid:items:added', function ( event, $grid ) {
				if ( ! $row.has( $grid ).length ) {
                                    return;
				}
                                
				vcResizeVideoBackground( $row );
			} );

		} else {
			$row.find( '.vc_video-bg' ).remove();
		}
	});
        
       

    }); // End doc ready

    /*----------------------------------------------------*/
    /*  One Page Portfolio Section
     /*----------------------------------------------------*/


    /*********************************
     init cubeportfolio
     *********************************/

    portfolioGrid.cubeportfolio({
        filters: '#filters-container',
        loadMore: '#loadMore-container',
        loadMoreAction: 'click',
        layoutMode: 'grid',
        rewindNav: true,
        scrollByPage: false,
        defaultFilter: '*',
        animationType: portfolioGrid.data('animationtype') ,
        gapHorizontal: ( portfolioGrid.data( 'gaphorizontal' ) == null ) ? 0: portfolioGrid.data( 'gaphorizontal' ),
        gapVertical: ( portfolioGrid.data( 'gapvertical' ) == null ) ? 0: portfolioGrid.data( 'gapvertical' ),
        gridAdjustment: 'responsive',
        mediaQueries: [{
                width: 1100,
                cols: ( portfolioGrid.data( 'medium-desktop' ) == null ) ? 3 : portfolioGrid.data( 'medium-desktop' )
            }, {
                width: 800,
                cols: ( portfolioGrid.data( 'tablet' ) == null ) ? 3 : portfolioGrid.data( 'tablet' )
            }, {
                width: 500,
                cols: ( portfolioGrid.data( 'mobile-landscape' ) == null ) ? 2 : portfolioGrid.data( 'mobile-landscape' )
            }, {
                width: 320,
                cols: ( portfolioGrid.data( 'mobile-portrait' ) == null ) ? 1 : portfolioGrid.data( 'mobile-portrait' )
            }],
        caption: portfolioGrid.data( 'caption' ),
        displayType: 'lazyLoading',
        displayTypeSpeed: 100,
        // lightbox
        lightboxDelegate: '.cbp-lightbox',
        lightboxGallery: true,
        lightboxTitleSrc: 'data-title',
        lightboxCounter: '<div class="cbp-popup-lightbox-counter">{{current}} of {{total}}</div>',
        // singlePage popup
        singlePageDelegate: '.cbp-singlePage',
        singlePageDeeplinking: true,
        singlePageStickyNavigation: true,
        singlePageCounter: '<div class="cbp-popup-singlePage-counter">{{current}} of {{total}}</div>',
        singlePageCallback: function( url, element ) {           

            var t = this;
            var data = {
		'action'    : 'engage_load_portfolio_page',
		'post_name' : url.substring(10),
                'security'  : engageShortcodeJs.ajax_nonce
            };
            
	    jQuery.post(engageShortcodeJs.ajaxurl, data, function(response) {               

                t.updateSinglePage( response );                   
            });
        },
    });

    /* --------------------------------*/
    /* - Window Load
     /* -------------------------------*/

    $( window ).load( function() {              

        /* --------------------------------*/
        /* - Initialize Map
         /* -------------------------------*/

        if (typeof (google) !== 'undefined' && $("#googleMap").length > 0) {
            initializeMap();
        }    
       
        
    }); // End on window load


    /* --------------------------------*/
    /* - Define Functions
    /* -------------------------------*/   

    function initializeAnimation() {       

        var animation = new WOW({
            boxClass: 'wow',
            animateClass: 'animated',
            offset:50,
            mobile: false, 
            live: true 
        });

        animation.init();
    }    
    
    $.fn.exists = function () {
        return this.length !== 0;
    }


    function initializeMap() {       

        var map_canvas = document.getElementById( 'googleMap' );
        var latitude = $( '#googleMap' ).data( 'latitude' );
        var longitude = $( '#googleMap' ).data( 'longitude' );
        var zoom = $( '#googleMap' ).data( 'zoom' );        
        var map_marker_img = $( '#googleMap' ).data( 'mapmarker' );

        var map_options = {
            center: new google.maps.LatLng( latitude, longitude ),
            zoom: zoom,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            scrollwheel: false,
            mapTypeControl: false,
            panControl: false,
            scaleControl: false,
            streetViewControl: false,
            zoomControl: false
        };

        var map = new google.maps.Map( map_canvas, map_options );

        var marker = new google.maps.Marker({
            position: new google.maps.LatLng( latitude, longitude ),
            map: map,            
            icon: map_marker_img
        });        

        var styles = [
            {
                "featureType": "all",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "saturation": 36
                    },
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 40
                    }
                ]
            },
            {
                "featureType": "all",
                "elementType": "labels.text.stroke",
                "stylers": [
                    {
                        "visibility": "on"
                    },
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 16
                    }
                ]
            },
            {
                "featureType": "all",
                "elementType": "labels.icon",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "administrative",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 20
                    }
                ]
            },
            {
                "featureType": "administrative",
                "elementType": "geometry.stroke",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 17
                    },
                    {
                        "weight": 1.2
                    }
                ]
            },
            {
                "featureType": "landscape",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 20
                    }
                ]
            },
            {
                "featureType": "poi",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 21
                    }
                ]
            },
            {
                "featureType": "road.highway",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 17
                    }
                ]
            },
            {
                "featureType": "road.highway",
                "elementType": "geometry.stroke",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 29
                    },
                    {
                        "weight": 0.2
                    }
                ]
            },
            {
                "featureType": "road.arterial",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 18
                    }
                ]
            },
            {
                "featureType": "road.local",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 16
                    }
                ]
            },
            {
                "featureType": "transit",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 19
                    }
                ]
            },
            {
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 17
                    }
                ]
            }
        ]
        map.setOptions( {styles: styles} );
    }

})(jQuery);