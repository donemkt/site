<?php
/*
 * Plugin Name: Engage Shortcodes
 * Plugin URI: http://demo.golothemes.com/engage
 * Description: Engage Shortcodes.
 * Version: 1.0
 * Author: golothemes
 * Author URI: http://golothemes.com/
 */

/**
 * Loads all functions for the Visual Composer 
 */


if( ! defined( 'ENGAGE_THEME_NAME' )) {
	define(	'ENGAGE_THEME_NAME', 'engage' );
}

if( ! defined( 'ENGAGE_META_PREFIX' )) {
	define( 'ENGAGE_META_PREFIX', 'engage_meta_' );
}

define( 'ENGAGE_IMAGE_URL',  plugin_dir_url( __FILE__ ) . '/assets/images' );


if ( ! class_exists( 'Engage_Visual_Composer_Extend' ) ) {
	class Engage_Visual_Composer_Extend {
		
		public function __construct() {
			
			//Setup VC
			add_action( 'init', array( $this, 'setup_vc' ) );
			
			//include shortcodes
			require_once( plugin_dir_path( __FILE__ ) . '/shortcodes.php' );	
			
						
            // Admin Init
            add_action( 'admin_init', array( $this, 'admin_init' ) );
			
			// Enque scripts for the admin
            add_action( 'admin_enqueue_scripts',  array( $this, 'admin_scripts' ) );
			
			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_enqueue' ) );	
			
			// Remove metaboxes
            add_action( 'do_meta_boxes', array( $this, 'remove_metaboxes' ) );           
			
		}
		
		
		/**
         * Setup VC
        */
		public function setup_vc() {
			
			if( ! defined( 'ENGAGE_VC_ACTIVE' )) {
				define( 'ENGAGE_VC_ACTIVE', class_exists( 'Vc_Manager' ) );
			}
			
			// Setup VC
			if ( function_exists( 'vc_set_as_theme' )) {
               vc_set_as_theme();
            }
			
			// Alter default post types
            if ( function_exists( 'vc_set_default_editor_post_types' ) ) {
                vc_set_default_editor_post_types( array( 'page' ) );
            }
			
			//set shotcodes template directory
			if ( function_exists( 'vc_set_shortcodes_templates_dir' ) ) {
				vc_set_shortcodes_templates_dir( plugin_dir_path( __FILE__ ) . '/vc-templates' );
			}
		}
				
		/**
         * Run on admin-init      
         */
        public function admin_init() {
			
			$this -> remove_elements();
            
            // Remove parameters
            $this -> remove_params();

            // Add Params
            if ( function_exists( 'vc_add_param' ) ) {
                require_once( plugin_dir_path(__FILE__) . '/add-params.php' );
            }  
		}
		
		public function admin_scripts() {          
            
			// Load FontAwesome
			wp_enqueue_style( 'font-awesome', plugin_dir_url( __FILE__ ) . '/assets/css/icons/font-awesome.min.css' );
		
			//Load Ion icons
			wp_enqueue_style( 'ionicons', plugin_dir_url( __FILE__ ) . '/assets/css/icons/ionicons.min.css' );
		
            // Load custom admin scripts
            wp_enqueue_style( 'engage-vc-extend', plugin_dir_url( __FILE__ ) . '/assets/vc-extend.css' );
        }
		
		/**
         * Remove Element         
         */
        public function remove_elements() {		
            
            // Array of elements to remove
            $elements = array(
				'vc_wp_tagcloud',
                'vc_wp_archives',
                'vc_wp_calendar',
                'vc_wp_pages',
                'vc_wp_links',
                'vc_wp_posts',
				'vc_wp_categories',
                'vc_wp_rss',
                'vc_wp_text',
                'vc_wp_meta',
                'vc_wp_recentcomments',								
				'vc_wp_search',				
				'vc_wp_custommenu',
				'vc_basic_grid',
				'vc_media_grid',
				'vc_masonry_grid',
				'vc_masonry_media_grid',
				'vc_tta_pageable',
				'vc_widget_sidebar',
				'vc_posts_slider',
				'vc_gallery',
				'vc_images_carousel',
				'vc_cta',
				'vc_tabs',
				'vc_tour',
				'vc_accordion',
				'vc_button',
				'vc_button2',
				'vc_cta_button',
				'vc_cta_button2',
            );
           
            // Loop through and remove default Visual Composer Elements
			if ( function_exists( 'vc_remove_element' )) {
				
				foreach ( $elements as $element ) {
					vc_remove_element( $element );
				}
			}

        }	
		
		/**
         * Remove Element params        
         */
        public function remove_params() {
           
            // Array of params to remove
            $params = array(

                // Rows
                'vc_row'            => array(
                    'full_width',
                    'video_bg',
                    'video_bg_url',
                    'full_height',
					'gap',
					'columns_placement',
					'equal_height',
					'parallax',
					'parallax_image',
					'video_bg_parallax',
					'content_placement',
					'css',
					'el_id',
					'el_class',
					'parallax_speed_video',
					'parallax_speed_bg'
                ),

                // Row Inner
                'vc_row_inner'      => array(
                    'css',
                ),
               
                // Seperator w/ Text
                'vc_text_separator' => array(
                    'color',
                    'el_width',
                    'accent_color',
                ),
						

                // Columns
                'vc_column'         => array(
                    'css',                
                ),
               
				
				// Progress Bar
                'vc_progress_bar'   => array(
                    'el_class',
					'options',				
					'units',
					'bgcolor',
					'custombgcolor',
					'customtxtcolor',
					'values',
					'css',
                ),
				
				// Google Map
               'vc_gmaps'   => array(                   
				   'title',
				   'link',
				   'size',			  
				   'el_class',
				   'css'
                ),				
				
            );
         
            // Loop through and remove default Visual Composer params
			
			if ( function_exists( 'vc_remove_param' )) {				
			
				foreach ( $params as $key => $val ) {
					if ( ! is_array( $val ) ) {
						return;
					}
					foreach ( $val as $remove_param ) {
						vc_remove_param( $key, $remove_param );
					}
				}
			}

        }		
				
		/**
         * Remove metaboxes         
         */
        public function remove_metaboxes() {           

            // Loop through post types and remove params
            $post_types = get_post_types( '', 'names' ); 
            foreach ( $post_types as $post_type ) {
                remove_meta_box( 'vc_teaser',  $post_type, 'side' );
            }

        }	
		
		/**
		* Load styles and scripts in frontend
		*/
	    public function frontend_enqueue() {

		    $this -> frontend_styles();
		    $this -> frontend_scripts();

	    }

	   /**
		* Loads all required CSS for the theme
		*/
	   private function frontend_styles() {
		  
		  // Load Visual composer CSS first so it's easier to override
		   if ( ENGAGE_VC_ACTIVE ) {
			  wp_enqueue_style( 'js_composer_front' );
		   }	

		   wp_enqueue_style( 'font-awesome', plugin_dir_url( __FILE__ ) . '/assets/css/icons/font-awesome.min.css' );			
		   wp_enqueue_style( 'ionicons', plugin_dir_url( __FILE__ ) . '/assets/css/icons/ionicons.min.css' );	

		   wp_enqueue_style( 'animate', plugin_dir_url( __FILE__ ) . '/assets/css/animate/animate.css' );   

		   wp_enqueue_style( 'owl-carousel', plugin_dir_url( __FILE__ ) . '/assets/css/owl/owl.carousel.css' );   	

		   wp_enqueue_style( 'magnific-popup', plugin_dir_url( __FILE__ ) . '/assets/css/popup/magnific-popup.css' );

		   wp_enqueue_style( 'jquery-custom-scrollbar', plugin_dir_url( __FILE__ ) . '/assets/css/scrollbar/jquery.mCustomScrollbar.css' );  

		   wp_enqueue_style( 'engage-hover', plugin_dir_url( __FILE__ ) . '/assets/css/hover/hover_pack.css' );  

		   wp_enqueue_style( 'engage-cubeportfolio',plugin_dir_url( __FILE__ ) . '/assets/css/cubeportfolio/cubeportfolio.min.css' );       			
		   	   
		   //Shortcodes
		   wp_register_style( 'engage-shortcodes', plugin_dir_url( __FILE__ ) . '/assets/css/shortcodes.css','engage-style' );			
		 	 
		   if(  wp_get_theme() != 'Engage' ) {
			   wp_enqueue_style( 'engage-shortcodes' );			
		   }

		   // Remove unwanted scripts
		   if ( ENGAGE_VC_ACTIVE ) {
			   wp_deregister_style( 'js_composer_custom_css' );
		   }

	   }

	   /**
		* Loads all required scripts for the theme
		*/
	   private function frontend_scripts() {
		   
		    global $engage_theme_settings;
		
			$animation_switch = intval( $engage_theme_settings[ 'animation-switch' ] );		
			$minify_js_switch = intval( $engage_theme_settings[ 'minify-js-switch' ] );		
			$retina_js_switch = intval( $engage_theme_settings[ 'retina-js-switch' ] );			

			// jQuery main script
			wp_enqueue_script( 'jquery' );	

			 // Localize array
			$localize_array = array(
				'animationSwitch'   => $animation_switch,				
				'ajaxurl'			=> admin_url('admin-ajax.php'),
				'ajax_nonce'        => wp_create_nonce('engage-secure-ajax'),
			);

			$localize_array = apply_filters( 'engage_shortcode_js', $localize_array );

			// Load minified global scripts
			if ( $minify_js_switch == 1 ) {		

				// Load minified js
				wp_enqueue_script( 'engage-min', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/plugin.js', array( 'jquery' ), '', true );      	
			}        
			// Load all non-minified js
			else {

				// Core plugins												

				wp_enqueue_script( 'engage-cubeportfolio', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/jquery.cubeportfolio.min.js', array( 'jquery' ), '', true );

				wp_enqueue_script( 'jquery-appear', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/appear.mini.js', array( 'jquery' ), '', true );

				wp_enqueue_script( 'jquery-easing', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/jquery.easing-1.3.pack.mini.js', array( 'jquery' ), '', true );

				wp_enqueue_script( 'owl-carousel', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/owl.carousel.min.js', array( 'jquery' ), '', true );		

				wp_enqueue_script( 'magnific-popup', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/jquery.magnific-popup.min.js', array( 'jquery' ), '', true );          

				wp_enqueue_script( 'jquery-custom-scrollbar', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/jquery.mCustomScrollbar.concat.min.js', array( 'jquery' ), '', true );          

				wp_enqueue_script( 'jquery-counto', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/jquery.countTo-mini.js', array( 'jquery' ), '', true );          

				wp_enqueue_script( 'wow', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/wow.min.js', array( 'jquery' ), '', true );          

				wp_enqueue_script( 'jquery-matchheight', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/jquery.matchHeight-min.js', array( 'jquery' ), '', true );		 				
				
			}

			// Retina.js
			if ( $retina_js_switch == 1 ) {
				wp_enqueue_script( 'retina', plugin_dir_url( __FILE__ ) . '/assets/js/plugins/retina.min.js', array( 'jquery' ), '', true );
			}


			wp_enqueue_script( 'google-map', '//maps.googleapis.com/maps/api/js', '', '', true );	 

			wp_enqueue_script( 'wpb_composer_front_js' );		

			wp_enqueue_script( 'engage-shortcodes', plugin_dir_url( __FILE__ ) . '/assets/js/shortcodes.js', '', '', true );		   

			// Localize
			wp_localize_script( 'engage-shortcodes', 'engageShortcodeJs', $localize_array );	 	
		
	   }
		
	}
	
	$engage_vc_extend = new Engage_Visual_Composer_Extend();
}

