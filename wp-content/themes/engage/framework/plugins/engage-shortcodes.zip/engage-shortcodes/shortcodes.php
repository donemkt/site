<?php

/* 
 * Includes all the shortcodes files
 */


require_once( plugin_dir_path(__FILE__) . '/functions.php' );

require_once( plugin_dir_path(__FILE__) . '/lib/twitter-api-wordpress.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/counter.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/special_heading.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/animated_icon_box.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/icon_box.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/featured_img_box.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/pricing_box.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/widget_subscribe_form.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/blog_grid.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/portfolio_grid.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/address_block.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/testimonial_slider.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/client_logo_slider.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/team_member.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/twitter_feeds_slider.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/call_to_action.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/button.php' );

require_once( plugin_dir_path(__FILE__) . '/shortcodes/video_modal.php' );


