<?php

/**
 * Shortcode attributes
 * @var $atts
 * @var $title
 * @var $values
 * @var $units
 * @var $bgcolor
 * @var $custombgcolor
 * @var $customtxtcolor
 * @var $options
 * @var $el_class
 * @var $css
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Progress_Bar
 */
$title = $values = '';
$output = '';

extract( shortcode_atts( array(	
	'title'					=> '',
	'values'				=>  urlencode( json_encode( array(
									array(
										'label' => esc_html__( 'Development', 'engage' ),
										'value' => '90',
									),
									array(
										'label' => esc_html__( 'Design', 'engage' ),
										'value' => '80',
									),
									array(
										'label' => esc_html__( 'Marketing', 'engage' ),
										'value' => '70',
									),
								) ) ),	
	'animation_effect'		=> '',
	'animation_delay'		=> '',
	'animation_duration'	=> ''
), $atts ) );

//animation
$animation_class = '';
$animation_delay_attr = '';
$animation_duration_attr = '';
		
if ( $animation_effect != '' ) {
	$animation_class = 'wow '.$animation_effect;		
	$animation_delay_attr = 'data-wow-delay="'.esc_attr( $animation_delay ).'s"';
	$animation_duration_attr = 'data-wow-duration="'.esc_attr( $animation_duration ).'s"';
}

$output .= '<div class="progress-wrapper '.esc_attr( $animation_class ).'" '.$animation_delay_attr.' '.$animation_duration_attr.'>';

if ( $title ) {
	$output .= '<h5>'.esc_html( $title ).'</h5>';
}

$output .= '<div class="skills marT50">';
$output .= '<ul class="skill-bar">';

$values = (array) vc_param_group_parse_atts( $values );

foreach ( $values as $data ) {
	
	$value = isset( $data['value'] ) ? $data['value'] : 0;
	$label = isset( $data['label'] ) ? $data['label'] : '';
	
	$bar_bgcolor  = '';
	$bar_txtcolor = '';
	
	$theme_color_class = '';		
	
	if ( isset( $data['use_theme_color'] ) ) {			
		$theme_color_class = 'theme-bg-color';
	}	
	elseif ( isset( $data['customcolor'] ) ) {
		$bar_bgcolor = ' style="background-color: ' . esc_attr( $data['customcolor'] ) . ';"';
	}
	
	if ( isset( $data['customtxtcolor'] ) ) {
		$bar_txtcolor = ' style="color: ' . esc_attr( $data['customtxtcolor'] ) . ';"';
	}
	
	$output .= '<li class="active progress">';
    $output .= '<div class="skill-bar-wrap">';
    $output .= '<div data-width="'.esc_attr( $value ).'" class="progress-bar '.esc_attr( $theme_color_class ).'" data-name="'.esc_attr( $label ).'"  '.$bar_bgcolor.'>';
	$output .= '<span class="skill-name" '.$bar_txtcolor.'>'.esc_html( $label ).'</span>';
	$output .= '<span class="percentage" '.$bar_txtcolor.'>'.esc_html( $value ).'%</span>';
	$output	.= '</div>';
    $output .= '</div>';
    $output .= '</li>';		
}

$output .= '</ul>';
$output .= '</div>';
$output .= '</div>';

echo $output . $this->endBlockComment( 'progress_bar' ) . "\n";
