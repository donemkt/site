<?php
$output = '';
extract( shortcode_atts( array(	
    'zoom'					=>	'16',
	'map_height'			=>  '620px', 
    'latitude'				=>	'',
    'longitude'				=>	'',		
	'map_marker'			=> '',	
), $atts ) );

$map_style = '';

if ( $map_height ) {
	$map_style = 'height:'.$map_height;
}

if ( $map_style ) {	
	$map_style = 'style = '.esc_attr( $map_style );
}

$output .= '<div class="map-block clearfix" '.$map_style.'>';
$output .= '<div id="googleMap" class="clearfix" data-zoom="'.esc_attr( $zoom ).'" data-latitude="'.esc_attr( $latitude ).'" data-longitude="'.esc_attr( $longitude ).'" data-mapmarker="'.wp_get_attachment_url( esc_attr( $map_marker ) ).'"></div>';
$output .= '</div>';

echo $output;