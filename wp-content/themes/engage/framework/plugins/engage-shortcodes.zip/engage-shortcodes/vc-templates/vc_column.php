<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $width
 * @var $css
 * @var $offset
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Column
 */
$output = '';

extract( shortcode_atts( array(	
	'el_class'			=> '',
    'width'				=> '',
	'offset'			=> '',
	'use_bg_color'		=> '',
	'bg_color'			=> '#ffffff',
	'use_bg_image'		=> '',
	'bg_image'			=> '',
	'use_overlay'		=> '',	
	'overlay_image'		=> '',
	'overlay_color'		=> 'rgba(0,0,0,0.4)',	
	'no_padding'		=> '',
	'margin_top'		=> '',
	'margin_bottom'		=> '',
	'margin_left'		=> '',
	'margin_right'		=> '',
	'padding_top'		=> '',
	'padding_bottom'	=> '',
	'padding_left'		=> '',
	'padding_right'		=> ''
), $atts ) );



$background_style = '';
$background_class = '';

if ( $use_bg_color == 'yes' && $bg_color ) {	
	$background_style .= 'background-color:'. $bg_color .';';
}
else if ( $use_bg_image == 'yes' ) { //Background Image
		
	if ( $bg_image ) {	
		
		$bg_img_url = wp_get_attachment_url( $bg_image );		
		
		$background_style .= 'background-image: url('. esc_url( $bg_img_url ) .');';
		
	}
	else {
		$background_style .= 'background-image: url(http://placehold.it/1920x980);';
	}
	
	$background_class .= ' bg-image';
}

/*-----------------------------------------------------------------------------------*/
/*	- Margin Style
/*-----------------------------------------------------------------------------------*/
if ( $margin_top ) {	
	$background_style	.= 'margin-top:'. $margin_top .';';
}

if ( $margin_bottom ) {	
	$background_style	.= 'margin-bottom:'. $margin_bottom .';';
}

if ( $margin_left ) {	
	$background_style	.= 'margin-left:'. $margin_left .';';
}

if ( $margin_right ) {	
	$background_style	.= 'margin-right:'. $margin_right .';';
}

/*-----------------------------------------------------------------------------------*/
/*	- Padding Row Style
/*-----------------------------------------------------------------------------------*/

if ( $padding_top ) {	
	$background_style	.= 'padding-top:'. $padding_top .';';
}

if ( $padding_bottom ) {	
	$background_style	.= 'padding-bottom:'. $padding_bottom .';';
}

if ( $padding_left ) {	
	$background_style	.= 'padding-left:'. $padding_left .';';
}

if ( $padding_right ) {	
	$background_style	.= 'padding-right:'. $padding_right .';';
}


//Background style
if ( $background_style ) {
	$background_style = ' style="' . esc_attr( $background_style ) . '"';
}

//no padding class
if ( $no_padding ) {
	$background_class .= ' no-padding';
}

/*-----------------------------------------------------------------------------------*/
/*	- Overlay Style
/*-----------------------------------------------------------------------------------*/

$overlay_style = '';
$overlay_class = '';


if ( $use_overlay && $overlay_image ) {
	$overlay_class .= ' bg-pattern-overlay';
	$overlay_style .= 'background-image: url('. esc_url( wp_get_attachment_url( $overlay_image ) ) .');';
}

if ( $use_overlay && $overlay_color ) {
	$overlay_class .= ' bg-color-overlay';
	$overlay_style .= 'background-color: '.$overlay_color.';';
}

if ( $overlay_style ) {	
	$overlay_style = ' style="' . esc_attr( $overlay_style ) . '"';
	$background_class .= ' bg-overlay';
}



$width = wpb_translateColumnWidthToSpan( $width );
$width = vc_column_offset_class_merge( $offset, $width );

$css_classes = array(
	$this->getExtraClass( $el_class ),
	'wpb_column',
	'vc_column_container',
	$width
	//vc_shortcode_custom_css_class( $css ),
);

$wrapper_attributes = array();

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts ) );

$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . ' '.esc_attr( $background_class ).'"';

$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '  '.$background_style.'>';

if( $use_overlay && $overlay_class && $overlay_style ) {
	$output .= '<div class="'.esc_attr( $overlay_class ).'" '.$overlay_style.' ></div>';	
}

$output .= '<div class="wpb_wrapper">';
$output .= wpb_js_remove_wpautop( $content );
$output .= '</div>';

$output .= '</div>';

echo $output;