<?php

$output = '';

extract( shortcode_atts( array(
	'row_id'					=> '',	
	'container_width'			=> '',	
	'use_full_height_row'		=> '',
	'use_equal_columns'			=> '',
	'center_content'			=> '',	
	'use_bg_color'				=> '',
	'bg_color'					=> '#ffffff',
	'use_bg_image'				=> '',
	'bg_image'					=> '',
	'image_parallax'			=> '',
	'use_bg_video'				=> '',
	'video_link'				=> '',	
	'video_parallax'			=> '',	
	'mobile_bg_image'			=> '',
	'use_overlay'				=> '',	
	'overlay_image'				=> '',
	'overlay_color'				=> 'rgba(0,0,0,0.4)',	
	'margin_top'				=> '',
	'margin_bottom'				=> '',
	'margin_left'				=> '',
	'margin_right'				=> '',
	'padding_top'				=> '',
	'padding_bottom'			=> '',
	'padding_left'				=> '',
	'padding_right'				=> '',
	'el_class'					=> '',	
), $atts ) );


// Custom Row ID
$section_id = '';
if ( $row_id ) {
	$section_id = 'id="'. esc_attr( $row_id ) .'"';
}

/*-----------------------------------------------------------------------------------*/
/*	- Background Style
/*-----------------------------------------------------------------------------------*/

$background_style = '';
$background_attr = '';
$background_class = 'clearfix';


if ( $use_bg_color == 'yes' && $bg_color ) {	
	$background_style .= 'background-color:'. $bg_color .';';
}
else if ( $use_bg_image == 'yes' ) { //Background Image
		
	if ( $bg_image ) {	
		
		$bg_img_url = wp_get_attachment_url( $bg_image );		
		
		if ( $image_parallax ) {
			
			wp_enqueue_script( 'vc_jquery_skrollr_js' );			
			
			$background_class .= ' vc_parallax vc_parallax-'.$image_parallax;
			$background_attr  .= ' data-vc-parallax="2"';
			$background_attr  .= ' data-vc-parallax-image="'. esc_url( $bg_img_url ) .'"';
			
			if ( false !== strpos( $image_parallax, 'fade' ) ) {
				$background_class .= ' js-vc_parallax-o-fade';
				$background_attr  .= ' data-vc-parallax-o-fade="on"';
			} elseif ( false !== strpos( $image_parallax, 'fixed' ) ) {
				$background_class .= ' js-vc_parallax-o-fixed';
			}
		}
		else {
			$background_style .= 'background-image: url('. esc_url( $bg_img_url ) .');';
		}
	}
	else {
		$background_style .= 'background-image: url(http://placehold.it/1920x980);';
	}
	
	$background_class .= ' bg-image';
}
else if ( $use_bg_video == 'yes' ) { //Background video
		
	if ( $video_link ) {		
		
		$background_class .= ' vc_video-bg-container';
		
		wp_enqueue_script( 'vc_youtube_iframe_api_js' );
		
		if ( $video_parallax ) {
			
			wp_enqueue_script( 'vc_jquery_skrollr_js' );			
			
			$background_attr  .= ' data-vc-parallax-image="'. esc_url( $video_link ) .'"';
			
			$background_class .= ' vc_parallax vc_parallax-'.$video_parallax;
			$background_attr  .= ' data-vc-parallax="2"';	
			
			if ( false !== strpos( $video_parallax, 'fade' ) ) {
				$background_class .= ' js-vc_parallax-o-fade';
				$background_attr  .= ' data-vc-parallax-o-fade="on"';
			} elseif ( false !== strpos( $video_parallax, 'fixed' ) ) {
				$background_class .= ' js-vc_parallax-o-fixed';
			}
		}
		else {
			
			$background_attr  .= ' data-vc-video-bg="' . esc_url( $video_link ) . '"';			
		}
		
		if ( $mobile_bg_image ) {
			
			$mobile_bg_image_url = wp_get_attachment_url( $mobile_bg_image );		
			
			$background_attr  .= ' data-mobile-bg-image="' . esc_url( $mobile_bg_image_url ) . '"';		
		}
		
		
		$background_class .= ' bg-video';
	}
	else {
		$background_style .= 'background-image: url(http://placehold.it/1920x980);';
		$background_class .= ' bg-image';
	}
	
	
}

/*-----------------------------------------------------------------------------------*/
/*	- Margin Style
/*-----------------------------------------------------------------------------------*/
if ( $margin_top ) {	
	$background_style	.= 'margin-top:'. $margin_top .';';
}

if ( $margin_bottom ) {	
	$background_style	.= 'margin-bottom:'. $margin_bottom .';';
}

if ( $margin_left ) {	
	$background_style	.= 'margin-left:'. $margin_left .';';
}

if ( $margin_right ) {	
	$background_style	.= 'margin-right:'. $margin_right .';';
}

/*-----------------------------------------------------------------------------------*/
/*	- Padding Row Style
/*-----------------------------------------------------------------------------------*/

if ( $padding_top ) {	
	$background_style	.= 'padding-top:'. $padding_top .';';
}

if ( $padding_bottom ) {	
	$background_style	.= 'padding-bottom:'. $padding_bottom .';';
}

if ( $padding_left ) {	
	$background_style	.= 'padding-left:'. $padding_left .';';
}

if ( $padding_right ) {	
	$background_style	.= 'padding-right:'. $padding_right .';';
}


//Background style
if ( $background_style ) {
	$background_style = ' style="' . esc_attr( $background_style ) . '"';
}


/*-----------------------------------------------------------------------------------*/
/*	- Full height
/*-----------------------------------------------------------------------------------*/
if( $use_full_height_row == 'yes' ) {
	
	$background_class .= ' vc_row-o-full-height';
}

/*-----------------------------------------------------------------------------------*/
/*	- Use columns with same height
/*-----------------------------------------------------------------------------------*/
if( $use_equal_columns == 'yes' ) {
	
	$background_class .= ' gt_equal_heights';
}


/*-----------------------------------------------------------------------------------*/
/*	- Container Style
/*-----------------------------------------------------------------------------------*/

if( $container_width == 'full-width' ) {
	$background_class .= ' full-width';
}	
else {
	$background_class .= ' container';
}

	

/*-----------------------------------------------------------------------------------*/
/*	- Overlay Style
/*-----------------------------------------------------------------------------------*/

$overlay_style = '';
$overlay_class = '';


if ( $use_overlay && $overlay_image ) {
	$overlay_class .= ' bg-pattern-overlay';
	$overlay_style .= 'background-image: url('. esc_url( wp_get_attachment_url( $overlay_image ) ) .');';
}

if ( $use_overlay && $overlay_color ) {
	$overlay_class .= ' bg-color-overlay';
	$overlay_style .= 'background-color: '.$overlay_color.';';
}

if ( $overlay_style ) {	
	$overlay_style = ' style="' . esc_attr( $overlay_style ) . '"';
	$background_class .= ' bg-overlay';
}




/*-----------------------------------------------------------------------------------*/
/*	- Output the row
/*-----------------------------------------------------------------------------------*/
$output .= '<div '. $section_id .' class="section '. esc_attr( $background_class ) .'" '.$background_style.' '.$background_attr.' >';


if( $use_overlay && $overlay_class && $overlay_style ) {
	$output .= '<div class="'.esc_attr( $overlay_class ).'" '.$overlay_style.' ></div>';	
}

if ( $center_content ) {
	$output .= '<div class="container">';
}

$output .= '<div class="vc_row">';
	
// Main Output
$output .= wpb_js_remove_wpautop($content);
	
/*-----------------------------------------------------------------------------------*/
/*	- Close Row & return output
/*-----------------------------------------------------------------------------------*/

$output .= '</div>';

if ( $center_content ) {
	$output .= '</div>';
}
		
$output .= '</div>';

echo $output;