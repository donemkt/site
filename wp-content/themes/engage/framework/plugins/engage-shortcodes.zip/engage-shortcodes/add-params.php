<?php
/**
 * Add new params to Visual Composer elements 
 */


/*-----------------------------------------------------------------------------------*/
/*	- Rows
/*-----------------------------------------------------------------------------------*/

vc_add_param( "vc_row", array(
	"type"			=> "textfield",
	"heading"		=> esc_html__( "Row ID", 'engage' ),
	"param_name"	=> "row_id",
	"description"	=> esc_html__( "Enter row ID (Note: make sure it is unique).", 'engage'),
) );

vc_add_param("vc_row", array(
    "type"			=> "dropdown",
    "class"			=> "",
    "heading"		=> esc_html__("Row's Content Width", 'engage' ),
    "param_name"	=> "container_width",
    "value"			=> array(
							"Container" => "container",							
							"Full Width" => "full-width" 
						),
    "description"	=> esc_html__("Make the row's content width fullwidth. Useful for fullwidth Portfolio Grid or Portfolio Carousel.", 'engage')
));

vc_add_param( "vc_row", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Center Content", 'engage' ),
	'param_name'	=> 'center_content',
	'value'			=> array(
						  esc_html__( "Yes", 'engage' ) => 'yes'
						),
	'dependency'    => array(
							'element'   => 'container_width',
							'value'		=> 'full-width',
						),
	'description'	=> esc_html__( 'If checked content will be set in center.', 'engage' ),	
) );

vc_add_param( "vc_row", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Full height row", 'engage' ),
	'param_name'	=> 'use_full_height_row',
	'value'			=> array(
						  esc_html__( "Yes", 'engage' ) => 'yes'
						),
	'description'	=> esc_html__( 'If checked row will be set to full height.', 'engage' ),	
) );

vc_add_param( "vc_row", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Use Equal Columns", 'engage' ),
	'param_name'	=> 'use_equal_columns',
	'value'			=> array(
						  esc_html__( "Yes", 'engage' ) => 'yes'
						),
	'description'	=> esc_html__( 'If checked columns in row will be set to same height.', 'engage' ),	
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Extra class name', 'engage' ),
	'param_name'	=> 'el_class',	
	'description'	=> esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'engage' ),
) );

vc_add_param( "vc_row", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Use Color Background", 'engage' ),
	'param_name'	=> 'use_bg_color',
	'value'			=> array(
						esc_html__( "Yes", 'engage' ) => 'yes'
						),
	'description'	=> esc_html__( "If checked, color will be used as row background, will drop image and video selection", 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'colorpicker',
	'heading'		=> esc_html__( 'Color', 'engage' ),
	'param_name'	=> 'bg_color',
	'group'			=> esc_html__( 'Background', 'engage' ),
	'dependency'    => array(
							'element'   => 'use_bg_color',
							'not_empty' => true,
						),
) );

vc_add_param( "vc_row", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Use Image Background", 'engage' ),
	'param_name'	=> 'use_bg_image',
	'value'			=> array(
						esc_html__( "Yes", 'engage' ) => 'yes'
						),	
	'description'	=> esc_html__( "If checked, image will be used as row background, will drop video selection.", 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),	
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'attach_image',
	'heading'		=> esc_html__( 'Image', 'engage' ),
	'param_name'	=> 'bg_image',
	'description'	=> esc_html__( 'Select image from media library.', 'engage' ),	
	'dependency'    => array(
							'element'   => 'use_bg_image',
							'not_empty' => true,
						),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'dropdown',
	'heading'		=> esc_html__( 'Parallax', 'engage' ),
	'param_name'	=> 'image_parallax',
	'value'			=> array(
							esc_html__( 'None', 'engage' ) => '',
							esc_html__( 'Simple', 'engage' ) => 'content-moving',
							esc_html__( 'With fade', 'engage' ) => 'content-moving-fade',
						),
	'description'	=> esc_html__( 'Add parallax type background for row.', 'engage' ),
	'dependency'	=> array(
							'element' => 'use_bg_image',
							'not_empty' => true,
						),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( "vc_row", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Use Video Background", 'engage' ),
	'param_name'	=> 'use_bg_video',
	'value'			=> array(
						esc_html__( "Yes", 'engage' ) => 'yes'
						),	
	'description'	=> esc_html__( "If checked, video will be used as row background.", 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),	
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Embed YouTube video', 'engage' ),
	'param_name'	=> 'video_link',
	'admin_label'	=> true,
	'description'	=> esc_html__( 'Link to the video.Video will be off on mobile please select background image to appear if video is off.', 'engage' ),	
	'dependency'    => array(
						'element'   => 'use_bg_video',
						'not_empty' => true,
						),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'dropdown',
	'heading'		=> esc_html__( 'Parallax', 'engage' ),
	'param_name'	=> 'video_parallax',
	'value'			=> array(
							esc_html__( 'None', 'engage' ) => '',
							esc_html__( 'Simple', 'engage' ) => 'content-moving',
							esc_html__( 'With fade', 'engage' ) => 'content-moving-fade',
						),
	'description'	=> esc_html__( 'Add parallax type background for row.', 'engage' ),
	'dependency'	=> array(
							'element' => 'use_bg_video',
							'not_empty' => true,
						),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'attach_image',
	'heading'		=> esc_html__( 'Image on mobile', 'engage' ),
	'param_name'	=> 'mobile_bg_image',
	'description'	=> esc_html__( 'Select image from media library for mobile as video will be off.', 'engage' ),	
	'dependency'    => array(
							'element'   => 'use_bg_video',
							'not_empty' => true,
						),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );


vc_add_param( 'vc_row', array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( 'Overlay', 'engage' ),
	'param_name'	=> 'use_overlay',
	'value'			=> array(
							esc_html__( 'Yes', 'engage' ) => 'yes',							
						),
	'description'	=> esc_html__( "Check to enable overlay.", 'engage' ),
	'dependency'    => array(
							'element'   => 'use_bg_color',
							'is_empty' => true,
						),	
	'group'			=> esc_html__( 'Background', 'engage' )	
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'attach_image',
	'heading'		=> esc_html__( 'Overlay Image', 'engage' ),
	'param_name'	=> 'overlay_image',
	'dependency'    => array(
							'element'   => 'use_overlay',
							'not_empty'	=>  true,
						),
	'description'	=> esc_html__( 'Select overlay image from media library.', 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'colorpicker',
	'heading'		=> esc_html__( 'Overlay Color', 'engage' ),
	'param_name'	=> 'overlay_color',	
	'dependency'    => array(
							'element'   => 'use_overlay',
							'not_empty'	=>  true,
						),
	'value'			=> 'rgba(0,0,0,0.4)',
	'description'	=> esc_html__( 'Select overlay color.', 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );


vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Top', 'engage' ),
	'param_name'	=> 'margin_top',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Bottom', 'engage' ),
	'param_name'	=> 'margin_bottom',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Left', 'engage' ),
	'param_name'	=> 'margin_left',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Right', 'engage' ),
	'param_name'	=> 'margin_right',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Top', 'engage' ),
	'param_name'	=> 'padding_top',
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Bottom', 'engage' ),
	'param_name'	=> 'padding_bottom',
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );


vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Left', 'engage' ),
	'param_name'	=> 'padding_left',
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );

vc_add_param( 'vc_row', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Right', 'engage' ),
	'param_name'	=> 'padding_right',
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );


/*-----------------------------------------------------------------------------------*/
/*	- Column
/*-----------------------------------------------------------------------------------*/

vc_add_param( "vc_column", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Apply No Padding", 'engage' ),
	'param_name'	=> 'no_padding',
	'value'			=> array(
						esc_html__( "Yes", 'engage' ) => 'yes'
						),
	'description'	=> esc_html__( "If checked, no padding will be applied to column.", 'engage' ),	
) );

vc_add_param( "vc_column", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Use Color Background", 'engage' ),
	'param_name'	=> 'use_bg_color',
	'value'			=> array(
						esc_html__( "Yes", 'engage' ) => 'yes'
						),
	'description'	=> esc_html__( "If checked, color will be used as row background, will drop image and video selection", 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'colorpicker',
	'heading'		=> esc_html__( 'Color', 'engage' ),
	'param_name'	=> 'bg_color',	
	'dependency'    => array(
							'element'   => 'use_bg_color',
							'not_empty' => true,
						),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( "vc_column", array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( "Use Image Background", 'engage' ),
	'param_name'	=> 'use_bg_image',
	'value'			=> array(
						esc_html__( "Yes", 'engage' ) => 'yes'
						),	
	'description'	=> esc_html__( "If checked, image will be used as row background, will drop video selection.", 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),	
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'attach_image',
	'heading'		=> esc_html__( 'Image', 'engage' ),
	'param_name'	=> 'bg_image',
	'description'	=> esc_html__( 'Select image from media library.', 'engage' ),	
	'dependency'    => array(
							'element'   => 'use_bg_image',
							'not_empty' => true,
						),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'checkbox',
	'heading'		=> esc_html__( 'Overlay', 'engage' ),
	'param_name'	=> 'use_overlay',
	'value'			=> array(
							esc_html__( 'Yes', 'engage' ) => 'yes',							
						),
	'description'	=> esc_html__( "Check to enable overlay.", 'engage' ),
	'dependency'    => array(
							'element'   => 'use_bg_color',
							'is_empty' => true,
						),	
	'group'			=> esc_html__( 'Background', 'engage' )	
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'attach_image',
	'heading'		=> esc_html__( 'Overlay Image', 'engage' ),
	'param_name'	=> 'overlay_image',
	'dependency'    => array(
							'element'   => 'use_overlay',
							'not_empty'	=>  true,
						),
	'description'	=> esc_html__( 'Select overlay image from media library.', 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'colorpicker',
	'heading'		=> esc_html__( 'Overlay Color', 'engage' ),
	'param_name'	=> 'overlay_color',	
	'dependency'    => array(
							'element'   => 'use_overlay',
							'not_empty'	=>  true,
						),
	'value'			=> 'rgba(0,0,0,0.4)',
	'description'	=> esc_html__( 'Select overlay color.', 'engage' ),
	'group'			=> esc_html__( 'Background', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Top', 'engage' ),
	'param_name'	=> 'padding_top',
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Bottom', 'engage' ),
	'param_name'	=> 'padding_bottom',
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Left', 'engage' ),
	'param_name'	=> 'padding_left',
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Padding Right', 'engage' ),
	'param_name'	=> 'padding_right',	
	'group'			=> esc_html__( 'Padding', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Top', 'engage' ),
	'param_name'	=> 'margin_top',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Bottom', 'engage' ),
	'param_name'	=> 'margin_bottom',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Left', 'engage' ),
	'param_name'	=> 'margin_left',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

vc_add_param( 'vc_column', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Margin Right', 'engage' ),
	'param_name'	=> 'margin_right',
	'group'			=> esc_html__( 'Margin', 'engage' ),
) );

/*-----------------------------------------------------------------------------------*/
/*	- Progress Bar
/*-----------------------------------------------------------------------------------*/

vc_add_param( 'vc_progress_bar', array(
	'type'			=> 'param_group',
	'heading'		=> esc_html__( 'Progress Bar Data', 'engage' ),
	'param_name'	=> 'values',
	'description'	=> esc_html__( 'Enter values for prgoress bar.', 'engage' ),
	'value'			=> urlencode( json_encode( array(
							array(
								'label' => esc_html__( 'Development', 'engage' ),
								'value' => '90',
							),
							array(
								'label' => esc_html__( 'Design', 'engage' ),
								'value' => '80',
							),
							array(
								'label' => esc_html__( 'Marketing', 'engage' ),
								'value' => '70',
							),
						) ) ),
			'params' => array(
							array(
								'type' => 'textfield',
								'heading' => esc_html__( 'Label', 'engage' ),
								'param_name' => 'label',
								'description' => esc_html__( 'Enter the text for progress bar title.', 'engage' ),
								'admin_label' => true,
							),
							array(
								'type' => 'textfield',
								'heading' => esc_html__( 'Value', 'engage' ),
								'param_name' => 'value',
								'description' => esc_html__( 'Enter percentage value for bar.', 'engage' ),
								'admin_label' => true,
							),				
							array(
								"type" => 'checkbox',
								"heading" => esc_html__( "Use Theme Color for Progress Bar", 'engage' ),
								"param_name" => 'use_theme_color',
								"value" => array(
											esc_html__("Yes.", 'engage' ) => 'yes',
								 ),
								"description" => esc_html__("Use theme color for progress bar.", 'engage'),
							),
							array(
								'type' => 'colorpicker',
								'heading' => esc_html__( 'Custom color', 'engage' ),
								'param_name' => 'customcolor',
								"dependency" => array(
												'element' => 'use_theme_color',
												'is_empty' => true,
											),
								'description' => esc_html__( 'Select custom color for progress bar.', 'engage' ),
								'value' => '#202020',
							),
							array(
								'type' => 'colorpicker',
								'heading' => esc_html__( 'Custom text color', 'engage' ),
								'param_name' => 'customtxtcolor',
								'description' => esc_html__( 'Select custom progress bar text color.', 'engage' ),
								'value' => '#202020',
							),
						),
				)
		);
	

vc_add_param( 'vc_progress_bar', array(
	"type"			=> "dropdown",
	"heading"		=> esc_html__( "Animation Effect", 'engage' ),
	"param_name"	=> "animation_effect",
	'value'			=> array(						
							esc_html__( 'None', 'engage' ) => '',
							esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
							esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
							esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
							esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
							esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
							esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
							esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
							esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
							esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
							esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
							esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
							esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
							esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
							esc_html__( 'flipInX', 'engage' ) => 'flipInX',
							esc_html__( 'flipInY', 'engage' ) => 'flipInY',
							esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
							esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
							esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
							esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
							esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
							esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
							esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
							esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
							esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
							esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
							esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
							esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
							esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
							esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
							esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
							esc_html__( 'rollIn', 'engage' ) => 'rollIn',
						),
	
	"description"	=> esc_html__( 'Animation Effect for Heading.', 'engage' ),
	'group'			=> esc_html__( 'Animation', 'engage' ),
) );

vc_add_param( 'vc_progress_bar', array(
	"type"			=> "textfield",
	"heading"		=> esc_html__( "Animation Delay", 'engage' ),
	"param_name"	=> "animation_delay",
	"value"			=> "0.5",
	"description"	=> esc_html__( 'Animation Delay Timming.', 'engage' ),
	'group'			=> esc_html__( 'Animation', 'engage' ),
) );

vc_add_param( 'vc_progress_bar', array(
	"type"			=> "textfield",
	"heading"		=> esc_html__( "Animation Duration", 'engage' ),
	"param_name"	=> "animation_duration",
	"value"			=> "1",
	"description"	=> esc_html__('Animation Duration Timming.', 'engage'),
	"group"			=> esc_html__( 'Animation', 'engage' ),
 ) );


/*-----------------------------------------------------------------------------------*/
/*	- Google Map
/*-----------------------------------------------------------------------------------*/
vc_add_param( 'vc_gmaps', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Latitude', 'engage' ),
	'admin_label'	=> true,
	'param_name'	=> 'latitude',
) );

vc_add_param( 'vc_gmaps', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Longitude', 'engage' ),
	'admin_label'	=> true,
	'param_name'	=> 'longitude',
) );

vc_add_param( 'vc_gmaps', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Zoom', 'engage' ),
	'admin_label'	=> true,
	'param_name'	=> 'zoom',
) );

vc_add_param( 'vc_gmaps', array(
	'type'			=> 'textfield',
	'heading'		=> esc_html__( 'Map Height', 'engage' ),	
	'param_name'	=> 'map_height',
) );

vc_add_param( 'vc_gmaps', array(
	'type'			=> 'attach_image',
	'heading'		=> esc_html__( 'Map Marker', 'engage' ),
	'param_name'	=> 'map_marker',	
	'description'	=> esc_html__( 'Select image for map marker.', 'engage' ),		
) );

/*-----------------------------------------------------------------------------------*/
/*	- Column Text
/*-----------------------------------------------------------------------------------*/

vc_add_param( 'vc_column_text', array(
		"type" => "dropdown",
		"heading" => esc_html__( "Animation Effect", 'engage' ),
		"param_name" => "animation_effect",
		'value' => array(
			esc_html__( 'None', 'engage' ) => '',
			esc_html__( 'bounceIn', 'engage' ) => 'bounceIn',
			esc_html__( 'bounceInDown', 'engage' ) => 'bounceInDown',
			esc_html__( 'bounceInLeft', 'engage' ) => 'bounceInLeft',
			esc_html__( 'bounceInRight', 'engage' ) => 'bounceInRight',
			esc_html__( 'bounceInUp', 'engage' ) => 'bounceInUp',
			esc_html__( 'fadeIn', 'engage' ) => 'fadeIn',
			esc_html__( 'fadeInDown', 'engage' ) => 'fadeInDown',
			esc_html__( 'fadeInDownBig', 'engage' ) => 'fadeInDownBig',
			esc_html__( 'fadeInLeft', 'engage' ) => 'fadeInLeft',
			esc_html__( 'fadeInLeftBig', 'engage' ) => 'fadeInLeftBig',
			esc_html__( 'fadeInRight', 'engage' ) => 'fadeInRight',
			esc_html__( 'fadeInRightBig', 'engage' ) => 'fadeInRightBig',
			esc_html__( 'fadeInUp', 'engage' ) => 'fadeInUp',
			esc_html__( 'flipInX', 'engage' ) => 'flipInX',
			esc_html__( 'flipInY', 'engage' ) => 'flipInY',
			esc_html__( 'lightSpeedIn', 'engage' ) => 'lightSpeedIn',
			esc_html__( 'rotateIn', 'engage' ) => 'rotateIn',
			esc_html__( 'rotateInDownLeft', 'engage' ) => 'rotateInDownLeft',
			esc_html__( 'rotateInDownRight', 'engage' ) => 'rotateInDownRight',
			esc_html__( 'rotateInUpLeft', 'engage' ) => 'rotateInUpLeft',
			esc_html__( 'rotateInUpRight', 'engage' ) => 'rotateInUpRight',
			esc_html__( 'slideInUp', 'engage' ) => 'slideInUp',
			esc_html__( 'slideInDown', 'engage' ) => 'slideInDown',
			esc_html__( 'slideInLeft', 'engage' ) => 'slideInLeft',
			esc_html__( 'slideInRight', 'engage' ) => 'slideInRight',
			esc_html__( 'zoomIn', 'engage' ) => 'zoomIn',
			esc_html__( 'zoomInDown', 'engage' ) => 'zoomInDown',
			esc_html__( 'zoomInLeft', 'engage' ) => 'zoomInLeft',
			esc_html__( 'zoomInRight', 'engage' ) => 'zoomInRight',
			esc_html__( 'zoomInUp', 'engage' ) => 'zoomInUp',
			esc_html__( 'rollIn', 'engage' ) => 'rollIn',
		),
		"description" => esc_html__( 'Animation Effect for feature box.', 'engage' ),
		'group' => esc_html__( 'Animation', 'engage' ),
	   )
);

vc_add_param( 'vc_column_text', array(
	"type"			=> "textfield",					
	"heading"		=> esc_html__( "Animation Delay", 'engage' ),
	"param_name"	=> "animation_delay",
	"value"			=> "0.5",					
	"description"	=> esc_html__( 'Animation Delay Timming in seconds. Default is 0.5', 'engage' ),
	"group"			=> esc_html__( 'Animation', 'engage' ),
) );

vc_add_param( 'vc_column_text', array(
	"type"			=> "textfield",					
	"heading"		=> esc_html__( "Animation Duration", 'engage' ),
	"param_name"	=> "animation_duration",
	"value"			=> "1",					
	"description"	=> esc_html__( 'Animation Duration Timming in seconds. Default is 1.', 'engage' ),
	"group"			=> esc_html__( 'Animation', 'engage' ),
) );
