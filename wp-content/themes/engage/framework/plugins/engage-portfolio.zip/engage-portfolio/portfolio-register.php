<?php
/*
 * Plugin Name: Engage Portfolio
 * Plugin URI: http://demo.golothemes.com/engage
 * Description: Engage Portfolio for adding portfolio.
 * Version: 1.0
 * Author: golothemes
 * Author URI: http://golothemes.com/
 */

require plugin_dir_path( __FILE__ ) . '/portfolio-functions.php';

if ( ! class_exists( 'Engage_Portfolio_Post_Type' ) ) {
	class Engage_Portfolio_Post_Type {

		function __construct() {

			// Adds the portfolio post type and taxonomies			
			add_action( 'init', array( $this, 'register' ) );
			
			add_action( 'admin_menu' , array( $this, 'portfolio_posts_sort' ) );			
			
			add_action( 'wp_ajax_portfolio_sort', array( $this, 'portfolio_posts_sort_order' ) );
			
			add_action( 'admin_print_styles', array( $this, 'portfolio_posts_sort_styles' ) );
			
		}
		
		function register() {

			/**
			 * Enable the Portfolio custom post type			 
			 */

			$labels = array(
				'name'					=> esc_html__( 'Portfolio', 'engage' ),
				'singular_name'			=> esc_html__( 'Portfolio Item', 'engage' ),
				'add_new'				=> esc_html__( 'Add New Item', 'engage' ),
				'add_new_item'			=> esc_html__( 'Add New Portfolio Item', 'engage' ),
				'edit_item'				=> esc_html__( 'Edit Portfolio Item', 'engage' ),
				'new_item'				=> esc_html__( 'Add New Portfolio Item', 'engage' ),
				'view_item'				=> esc_html__( 'View Item', 'engage' ),
				'search_items'			=> esc_html__( 'Search Portfolio', 'engage' ),
				'not_found'				=> esc_html__( 'No portfolio items found', 'engage' ),
				'not_found_in_trash'	=> esc_html__( 'No portfolio items found in trash', 'engage' )
			);
			
			$args = array(
				'labels'			=> $labels,
				'public'			=> true,
				'supports'			=> array( 'title', 'editor', 'thumbnail', 'revisions' ),
				'capability_type'	=> 'post',
				'rewrite'			=> array( 'slug' => 'portfolio-item' ),
				'has_archive'		=> false,
				'menu_icon'			=> 'dashicons-portfolio',
				'menu_position'		=> 20,
			); 
			
			
			register_post_type( 'portfolio', $args );
			

			/**
			 * Register a taxonomy for Portfolio Categories
			 */

			$labels = array(
				'name'							=> esc_html__( 'Portfolio Categories', 'engage' ),
				'singular_name'					=> esc_html__( 'Portfolio Category', 'engage' ),
				'search_items'					=> esc_html__( 'Search Portfolio Categories', 'engage' ),
				'popular_items'					=> esc_html__( 'Popular Portfolio Categories', 'engage' ),
				'all_items'						=> esc_html__( 'All Portfolio Categories', 'engage' ),
				'parent_item'					=> esc_html__( 'Parent Portfolio Category', 'engage' ),
				'parent_item_colon'				=> esc_html__( 'Parent Portfolio Category:', 'engage' ),
				'edit_item'						=> esc_html__( 'Edit Portfolio Category', 'engage' ),
				'update_item'					=> esc_html__( 'Update Portfolio Category', 'engage' ),
				'add_new_item'					=> esc_html__( 'Add New Portfolio Category', 'engage' ),
				'new_item_name'					=> esc_html__( 'New Portfolio Category Name', 'engage' ),
				'separate_items_with_commas'	=> esc_html__( 'Separate portfolio categories with commas', 'engage' ),
				'add_or_remove_items'			=> esc_html__( 'Add or remove portfolio categories', 'engage' ),
				'choose_from_most_used'			=> esc_html__( 'Choose from the most used portfolio categories', 'engage' ),
				'menu_name'						=> esc_html__( 'Portfolio Categories', 'engage' ),
			);

			$args = array(
				'labels'				=> $labels,
				'public'				=> true,
				'show_in_nav_menus'		=> true,
				'show_ui'				=> true,
				'show_tagcloud'			=> true,
				'hierarchical'			=> true,
				'rewrite'				=> array( 'slug' => 'portfolio-category' ),
				'query_var'				=> true
			);
			
			register_taxonomy( 'portfolio_category', array( 'portfolio' ), $args );

		}
		
		function portfolio_posts_sort() {
			
			add_submenu_page( 'edit.php?post_type=portfolio', esc_html__( 'Sort Porfolio', 'engage' ), esc_html__( 'Sort Porfolio', 'engage' ), 'edit_posts', 'sort_portfolio', array( $this, 'portfolio_posts_sort_callback' ) );									
		}
		
		function portfolio_posts_sort_callback() {
			
			$portfolio = new WP_Query( 'post_type=portfolio&posts_per_page=-1&orderby=menu_order&order=ASC' );

			?>
			<div class="wrap">
				<h3><?php esc_html_e( 'Sort Porfolio', 'engage' ); ?><img src="<?php echo esc_url( home_url('/') ); ?>wp-admin/images/loading.gif" id="loading-animation" /></h3>
				<ul id="slide-list">
					<?php if( $portfolio -> have_posts() ) : ?>
						<?php while ( $portfolio -> have_posts() ) { $portfolio -> the_post(); ?>
							<li id="<?php the_id(); ?>"><?php the_title(); ?></li>			
						<?php } ?>
					<?php else : ?>
						<li><?php esc_html_e( 'There is no Portfolio Created', 'engage' ); ?></li>		
					<?php endif; ?>
				</ul>
			</div>
		<?php
		}
		
		function portfolio_posts_sort_styles() {
			
			$screen = get_current_screen();		
	
			if( $screen -> id == 'portfolio_page_sort_portfolio' ) {
				
				wp_enqueue_style( 'engage-sort-stylesheet', plugin_dir_url( __FILE__ ) . '/css/sort-stylesheet.css', array(), false, false );
				wp_enqueue_script( 'jquery-ui-sortable' );
				wp_enqueue_script( 'engage-sort-script', plugin_dir_url( __FILE__ ) . '/js/sort-script.js', array(), false, true );				
			}
		}
		
		
		function portfolio_posts_sort_order() {
			
			global $wpdb;

			$order = explode( ',', $_POST['order'] );
			$counter = 0;

			foreach ( $order as $slide_id ) {
				$wpdb -> update( $wpdb->posts, array( 'menu_order' => $counter ), array( 'ID' => $slide_id ) );
				$counter++;
			}
			
			die(1);
		}
		
	}
	
	new Engage_Portfolio_Post_Type;
	
}
